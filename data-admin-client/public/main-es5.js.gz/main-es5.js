function _createForOfIteratorHelper(o, allowArrayLike) { var it; if (typeof Symbol === "undefined" || o[Symbol.iterator] == null) { if (Array.isArray(o) || (it = _unsupportedIterableToArray(o)) || allowArrayLike && o && typeof o.length === "number") { if (it) o = it; var i = 0; var F = function F() {}; return { s: F, n: function n() { if (i >= o.length) return { done: true }; return { done: false, value: o[i++] }; }, e: function e(_e) { throw _e; }, f: F }; } throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); } var normalCompletion = true, didErr = false, err; return { s: function s() { it = o[Symbol.iterator](); }, n: function n() { var step = it.next(); normalCompletion = step.done; return step; }, e: function e(_e2) { didErr = true; err = _e2; }, f: function f() { try { if (!normalCompletion && it["return"] != null) it["return"](); } finally { if (didErr) throw err; } } }; }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"], {
  /***/
  "./$$_lazy_route_resource lazy recursive":
  /*!******************************************************!*\
    !*** ./$$_lazy_route_resource lazy namespace object ***!
    \******************************************************/

  /*! no static exports found */

  /***/
  function $$_lazy_route_resourceLazyRecursive(module, exports) {
    function webpackEmptyAsyncContext(req) {
      // Here Promise.resolve().then() is used instead of new Promise() to prevent
      // uncaught exception popping up in devtools
      return Promise.resolve().then(function () {
        var e = new Error("Cannot find module '" + req + "'");
        e.code = 'MODULE_NOT_FOUND';
        throw e;
      });
    }

    webpackEmptyAsyncContext.keys = function () {
      return [];
    };

    webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
    module.exports = webpackEmptyAsyncContext;
    webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";
    /***/
  },

  /***/
  "./node_modules/base64-js/index.js":
  /*!*****************************************!*\
    !*** ./node_modules/base64-js/index.js ***!
    \*****************************************/

  /*! no static exports found */

  /***/
  function node_modulesBase64JsIndexJs(module, exports, __webpack_require__) {
    "use strict";

    exports.byteLength = byteLength;
    exports.toByteArray = toByteArray;
    exports.fromByteArray = fromByteArray;
    var lookup = [];
    var revLookup = [];
    var Arr = typeof Uint8Array !== 'undefined' ? Uint8Array : Array;
    var code = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

    for (var i = 0, len = code.length; i < len; ++i) {
      lookup[i] = code[i];
      revLookup[code.charCodeAt(i)] = i;
    } // Support decoding URL-safe base64 strings, as Node.js does.
    // See: https://en.wikipedia.org/wiki/Base64#URL_applications


    revLookup['-'.charCodeAt(0)] = 62;
    revLookup['_'.charCodeAt(0)] = 63;

    function getLens(b64) {
      var len = b64.length;

      if (len % 4 > 0) {
        throw new Error('Invalid string. Length must be a multiple of 4');
      } // Trim off extra bytes after placeholder bytes are found
      // See: https://github.com/beatgammit/base64-js/issues/42


      var validLen = b64.indexOf('=');
      if (validLen === -1) validLen = len;
      var placeHoldersLen = validLen === len ? 0 : 4 - validLen % 4;
      return [validLen, placeHoldersLen];
    } // base64 is 4/3 + up to two characters of the original data


    function byteLength(b64) {
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }

    function _byteLength(b64, validLen, placeHoldersLen) {
      return (validLen + placeHoldersLen) * 3 / 4 - placeHoldersLen;
    }

    function toByteArray(b64) {
      var tmp;
      var lens = getLens(b64);
      var validLen = lens[0];
      var placeHoldersLen = lens[1];
      var arr = new Arr(_byteLength(b64, validLen, placeHoldersLen));
      var curByte = 0; // if there are placeholders, only get up to the last complete 4 chars

      var len = placeHoldersLen > 0 ? validLen - 4 : validLen;
      var i;

      for (i = 0; i < len; i += 4) {
        tmp = revLookup[b64.charCodeAt(i)] << 18 | revLookup[b64.charCodeAt(i + 1)] << 12 | revLookup[b64.charCodeAt(i + 2)] << 6 | revLookup[b64.charCodeAt(i + 3)];
        arr[curByte++] = tmp >> 16 & 0xFF;
        arr[curByte++] = tmp >> 8 & 0xFF;
        arr[curByte++] = tmp & 0xFF;
      }

      if (placeHoldersLen === 2) {
        tmp = revLookup[b64.charCodeAt(i)] << 2 | revLookup[b64.charCodeAt(i + 1)] >> 4;
        arr[curByte++] = tmp & 0xFF;
      }

      if (placeHoldersLen === 1) {
        tmp = revLookup[b64.charCodeAt(i)] << 10 | revLookup[b64.charCodeAt(i + 1)] << 4 | revLookup[b64.charCodeAt(i + 2)] >> 2;
        arr[curByte++] = tmp >> 8 & 0xFF;
        arr[curByte++] = tmp & 0xFF;
      }

      return arr;
    }

    function tripletToBase64(num) {
      return lookup[num >> 18 & 0x3F] + lookup[num >> 12 & 0x3F] + lookup[num >> 6 & 0x3F] + lookup[num & 0x3F];
    }

    function encodeChunk(uint8, start, end) {
      var tmp;
      var output = [];

      for (var i = start; i < end; i += 3) {
        tmp = (uint8[i] << 16 & 0xFF0000) + (uint8[i + 1] << 8 & 0xFF00) + (uint8[i + 2] & 0xFF);
        output.push(tripletToBase64(tmp));
      }

      return output.join('');
    }

    function fromByteArray(uint8) {
      var tmp;
      var len = uint8.length;
      var extraBytes = len % 3; // if we have 1 byte left, pad 2 bytes

      var parts = [];
      var maxChunkLength = 16383; // must be multiple of 3
      // go through the array every three bytes, we'll deal with trailing stuff later

      for (var i = 0, len2 = len - extraBytes; i < len2; i += maxChunkLength) {
        parts.push(encodeChunk(uint8, i, i + maxChunkLength > len2 ? len2 : i + maxChunkLength));
      } // pad the end with zeros, but make sure to not forget the extra bytes


      if (extraBytes === 1) {
        tmp = uint8[len - 1];
        parts.push(lookup[tmp >> 2] + lookup[tmp << 4 & 0x3F] + '==');
      } else if (extraBytes === 2) {
        tmp = (uint8[len - 2] << 8) + uint8[len - 1];
        parts.push(lookup[tmp >> 10] + lookup[tmp >> 4 & 0x3F] + lookup[tmp << 2 & 0x3F] + '=');
      }

      return parts.join('');
    }
    /***/

  },

  /***/
  "./node_modules/ieee754/index.js":
  /*!***************************************!*\
    !*** ./node_modules/ieee754/index.js ***!
    \***************************************/

  /*! no static exports found */

  /***/
  function node_modulesIeee754IndexJs(module, exports) {
    exports.read = function (buffer, offset, isLE, mLen, nBytes) {
      var e, m;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var nBits = -7;
      var i = isLE ? nBytes - 1 : 0;
      var d = isLE ? -1 : 1;
      var s = buffer[offset + i];
      i += d;
      e = s & (1 << -nBits) - 1;
      s >>= -nBits;
      nBits += eLen;

      for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}

      m = e & (1 << -nBits) - 1;
      e >>= -nBits;
      nBits += mLen;

      for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}

      if (e === 0) {
        e = 1 - eBias;
      } else if (e === eMax) {
        return m ? NaN : (s ? -1 : 1) * Infinity;
      } else {
        m = m + Math.pow(2, mLen);
        e = e - eBias;
      }

      return (s ? -1 : 1) * m * Math.pow(2, e - mLen);
    };

    exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
      var e, m, c;
      var eLen = nBytes * 8 - mLen - 1;
      var eMax = (1 << eLen) - 1;
      var eBias = eMax >> 1;
      var rt = mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0;
      var i = isLE ? 0 : nBytes - 1;
      var d = isLE ? 1 : -1;
      var s = value < 0 || value === 0 && 1 / value < 0 ? 1 : 0;
      value = Math.abs(value);

      if (isNaN(value) || value === Infinity) {
        m = isNaN(value) ? 1 : 0;
        e = eMax;
      } else {
        e = Math.floor(Math.log(value) / Math.LN2);

        if (value * (c = Math.pow(2, -e)) < 1) {
          e--;
          c *= 2;
        }

        if (e + eBias >= 1) {
          value += rt / c;
        } else {
          value += rt * Math.pow(2, 1 - eBias);
        }

        if (value * c >= 2) {
          e++;
          c /= 2;
        }

        if (e + eBias >= eMax) {
          m = 0;
          e = eMax;
        } else if (e + eBias >= 1) {
          m = (value * c - 1) * Math.pow(2, mLen);
          e = e + eBias;
        } else {
          m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen);
          e = 0;
        }
      }

      for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

      e = e << mLen | m;
      eLen += mLen;

      for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

      buffer[offset + i - d] |= s * 128;
    };
    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
  /*!**************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
    \**************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAppComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<nz-layout class=\"left-layout\">\n  <nz-sider [nzWidth]=\"300\" [nzTheme]=\"'dark'\">\n    <div>\n      <div class=\"side_top\">\n        <div class=\"title\">\n          <h2 (click)=\"openDashBoard()\">\n            <i nz-icon nzType=\"code\" nzTheme=\"outline\"></i> Driving Data Warehouse\n          </h2>\n        </div>\n      </div>\n      <div class=\"search-box\">\n        <nz-input-group [nzPrefix]=\"reloadIcon\" [nzSuffix]=\"searchIcon\">\n          <input type=\"text\" nz-input placeholder=\"Search for collections\" class=\"search\" [(ngModel)]=\"searchText\"\n            (keyup)=\"filter()\" autocomplete=\"off\" spellcheck=\"false\" />\n        </nz-input-group>\n        <ng-template #reloadIcon><i nz-icon nzType=\"reload\" class=\"reload-dbs-btn\"\n            [nzTooltipTitle]=\"isLoadingDbs ? 'Loading...' : 'Reload'\" (click)=\"reloadSideNav()\" nzTooltipPlacement=\"top\"\n            nz-tooltip></i></ng-template>\n        <ng-template #searchIcon><i nz-icon nzType=\"search\" style=\"color: #c4c4c4;\"></i></ng-template>\n      </div>\n      <div class=\"side_explorer\">\n        <ul class=\"menu\">\n          <li *ngFor=\"let db of menuData\" (click)=\"expand($event, db)\">\n            <div class=\"{{\n                isInSearchMode ? 'db_item nav_item open' : 'db_item nav_item'\n              }}\">\n              {{ db.name\n              }}<span class=\"action\"><span><i nz-icon nzType=\"plus-circle\" nzTheme=\"outline\"\n                    nzTooltipTitle=\"Add new collection\" nzTooltipPlacement=\"top\" nz-tooltip\n                    (click)=\"openModal('addTable', { database: db.name })\"></i></span>\n                <span><i nz-icon nzType=\"delete\" nzTheme=\"fill\" nzTooltipTitle=\"Drop database\" nzTooltipPlacement=\"top\"\n                    nz-tooltip (click)=\"openModal('dropDataBase', { database: db.name })\"></i></span>\n              </span>\n            </div>\n            <ul>\n              <li *ngFor=\"let collection of db.collections\">\n                <div class=\"nav_item collection_item\" (click)=\"openTab(db.name, collection.name)\">\n                  {{collection.name}}&nbsp;\n                  <span class=\"action\">\n                    <span><i nz-icon nzType=\"delete\" nzTheme=\"fill\" nzTooltipTitle=\"Drop collection\"\n                        nzTooltipPlacement=\"top\" nz-tooltip (click)=\"\n                          openModal('dropTable', {\n                            database: db.name,\n                            collection: collection.name\n                          })\n                        \"></i></span>\n                  </span>\n                </div>\n              </li>\n            </ul>\n          </li>\n        </ul>\n      </div>\n      <div>\n        <a nzType=\"link\" (click)=\"openModal('addDB', {})\" class=\"spl-button add-db-btn\">\n          <i nz-icon nzType=\"plus\" nzTheme=\"outline\"></i>Add Database\n        </a>\n      </div>\n    </div>\n  </nz-sider>\n  <nz-layout class=\"right-layout\">\n    <nz-content>\n      <nz-tabset [nzType]=\"'card'\" [nzSelectedIndex]=\"activeTabIndex\" *ngIf=\"tabs && tabs.length\">\n        <nz-tab *ngFor=\"let tab of tabs\" [nzTitle]=\"titleTemplate\">\n          <ng-template #titleTemplate>\n            <div title=\"{{ tab.database + '.' + tab.collection }}\">\n              {{\n              tab.collection.length > 28\n              ? tab.collection.substring(0, 28) + '...'\n              : tab.collection\n              }}<i nz-icon nzType=\"close\" class=\"ant-tabs-close-x\" (click)=\"closeTab(tab.id)\"></i>\n            </div>\n          </ng-template>\n          <app-collection [database]=\"tab.database\" [collection]=\"tab.collection\"></app-collection>\n        </nz-tab>\n      </nz-tabset>\n      <div *ngIf=\"(!tabs || tabs.length == 0) && active == 'databases'\" class=\"dashboard-stats\">\n        <nz-descriptions nzTitle=\"Database stats\">\n          <nz-descriptions-item nzTitle=\"Databases\">{{\n            stats.databases\n            }}</nz-descriptions-item>\n          <nz-descriptions-item nzTitle=\"Collections\">{{\n            stats.collections\n            }}</nz-descriptions-item>\n          <nz-descriptions-item nzTitle=\"Size\">{{\n            stats.size | fileSize: 2\n            }}</nz-descriptions-item>\n        </nz-descriptions>\n      </div>\n      <nz-table *ngIf=\"(!tabs || tabs.length == 0) && active == 'databases'\" #basicTable [nzData]=\"dbs.databases\"\n        nzBordered=\"true\" class=\"table_home\">\n        <thead>\n          <tr>\n            <th>Name</th>\n            <th>Size</th>\n            <th>Collections</th>\n          </tr>\n        </thead>\n        <tbody>\n          <tr *ngFor=\"let data of basicTable.data\">\n            <td>\n              <a href=\"javascript:void(0)\" (click)=\"showCollections(data)\">{{\n                data.name\n                }}</a>\n            </td>\n            <td>{{ data.sizeOnDisk | fileSize: 2 }}</td>\n            <td>{{ data.collections.length }}\n              <span class=\"drop-db\" style=\"float: right; cursor: pointer;\"><i nz-icon nzType=\"delete\" nzTooltipTitle=\"Drop database\" nzTooltipPlacement=\"top\"\n                nz-tooltip (click)=\"openModal('dropDataBase', { database: data.name })\"></i></span>\n            </td>\n          </tr>\n        </tbody>\n      </nz-table>\n\n      <div style=\"padding: 10px;\" *ngIf=\"(!tabs || tabs.length == 0) && active == 'databases'\">\n        <nz-tag nzColor=\"#211F1F\">\n          <a href=\"https://github.com/arunbandari/mongo-gui\" target=\"_blank\">\n            <i nz-icon nzType=\"github\"></i>\n            <span> GitHub</span>\n          </a>\n        </nz-tag>\n        <nz-tag nzColor=\"#c00\">\n          <a href=\"https://www.npmjs.com/package/mongo-gui\" target=\"_blank\">\n            <i nz-icon></i>\n            <span>npm</span>\n          </a>\n        </nz-tag>\n      </div>\n      <div *ngIf=\"(!tabs || tabs.length == 0) && active == 'collections'\" class=\"collection-stats\">\n        <nz-descriptions nzTitle=\"Collection stats\">\n          <nz-descriptions-item nzTitle=\"Database\">{{\n            db.name\n            }}</nz-descriptions-item>\n          <nz-descriptions-item nzTitle=\"Collections\">{{\n            db.collections.length\n            }}</nz-descriptions-item>\n          <nz-descriptions-item nzTitle=\"Size\">{{\n            db.sizeOnDisk | fileSize: 2\n            }}</nz-descriptions-item>\n        </nz-descriptions>\n      </div>\n      <nz-table *ngIf=\"(!tabs || tabs.length == 0) && active == 'collections'\" #basicTable [nzData]=\"db.collections\"\n        nzBordered=\"true\" class=\"table_home\">\n        <thead>\n          <tr>\n            <th>Name</th>\n            <th>Size</th>\n            <th>Documents</th>\n          </tr>\n        </thead>\n        <tbody>\n          <tr *ngFor=\"let collection of basicTable.data\">\n            <td>\n              <a href=\"javascript:void(0)\" (click)=\"openTab(db.name, collection.name)\">{{\n                collection.name\n                }}</a>\n            </td>\n            <td>{{ collection.stats.size | fileSize: 2 }}</td>\n            <td>{{ collection.stats.count }}\n              <span class=\"drop-table\" style=\"float: right; cursor: pointer;\">\n                <i nz-icon nzType=\"delete\" nzTooltipTitle=\"Drop collection\" nzTooltipPlacement=\"top\" nz-tooltip (click)=\"\n                openModal('dropTable', {\n                  database: db.name,\n                  collection: collection.name\n                })\n              \"></i></span></td>\n          </tr>\n        </tbody>\n      </nz-table>\n      <router-outlet></router-outlet>\n    </nz-content>\n  </nz-layout>\n</nz-layout>\n\n<nz-modal nzMaskClosable=\"false\" [(nzVisible)]=\"addTable\" (nzOnCancel)=\"closeModal('addTable')\" nzTitle=\"Add new collection\" [nzFooter]=\"null\"\n  [nzBodyStyle]=\"{height: '237px'}\">\n  <form nz-form [formGroup]=\"addTableForm\">\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"6\" [nzXs]=\"24\" nzRequired nzFor=\"database\">Database</nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\" nzExtra=\"New collection will be added to this database\">\n        <input nz-input formControlName=\"database\" id=\"database\" readonly />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"6\" [nzXs]=\"24\" nzFor=\"collection\" nzRequired>Collection</nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\" nzErrorTip=\"Please enter a valid name\">\n        <input nz-input id=\"collection\" formControlName=\"collection\" autocomplete=\"off\" spellcheck=\"false\" />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-control>\n        <div class=\"addTableFooter\">\n          <button class=\"add\" nz-button nzType=\"primary\" [disabled]=\"!addTableForm.valid || addTableLoader\"\n            (click)=\"createTable()\">\n            {{ addTableLoader ? 'Adding ...' : 'Add' }}\n          </button>\n          <button class=\"cancel\" nz-button nzType=\"default\" (click)=\"closeModal('addTable')\">\n            Cancel\n          </button>\n        </div>\n      </nz-form-control>\n    </nz-form-item>\n  </form>\n</nz-modal>\n\n<nz-modal nzMaskClosable=\"false\" [(nzVisible)]=\"dropTable\" nzTitle=\"Drop collection\" (nzOnCancel)=\"closeModal('dropTable')\"\n  [nzBodyStyle]=\"{height: '300px'}\" [nzFooter]=\"null\">\n  <form nz-form [formGroup]=\"dropTableForm\">\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"7\" [nzXs]=\"24\" nzRequired nzFor=\"database\">Database</nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\">\n        <input nz-input formControlName=\"database\" id=\"database\" readonly />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"7\" [nzXs]=\"24\" nzFor=\"collection\" nzRequired>Collection</nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\">\n        <input nz-input id=\"collection\" formControlName=\"collection\" readonly />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"7\" [nzXs]=\"24\" nzFor=\"confirmCollection\" nzRequired>Confirm collection</nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\" nzExtra=\"Please type the collection name to confirm.\">\n        <input nz-input id=\"confirmCollection\" formControlName=\"confirmCollection\" autocomplete=\"off\"\n          spellcheck=\"false\" />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-control>\n        <div class=\"dropTableFooter\">\n          <button class=\"drop\" nz-button nzType=\"danger\" [disabled]=\"!dropTableForm.valid || dropTableLoader\"\n            (click)=\"dropCollection()\">\n            {{ dropTableLoader ? 'Dropping ...' : 'Drop' }}\n          </button>\n          <button class=\"cancel\" nz-button nzType=\"default\" (click)=\"closeModal('dropTable')\">\n            Cancel\n          </button>\n        </div>\n      </nz-form-control>\n    </nz-form-item>\n  </form>\n</nz-modal>\n<nz-modal nzMaskClosable=\"false\" [(nzVisible)]=\"dropDataBase\" nzTitle=\"Drop database\" (nzOnCancel)=\"closeModal('dropDataBase')\"\n  [nzBodyStyle]=\"{height: '237px'}\" [nzFooter]=\"null\">\n  <form nz-form [formGroup]=\"dropDataBaseForm\">\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"7\" [nzXs]=\"24\" nzRequired nzFor=\"database\">\n        Database\n      </nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\">\n        <input nz-input formControlName=\"database\" id=\"database\" readonly />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"7\" [nzXs]=\"24\" nzFor=\"confirmDataBase\" nzRequired>\n        Confirm database\n      </nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\" nzExtra=\"Please type the database name to confirm.\">\n        <input nz-input id=\"confirmDataBase\" formControlName=\"confirmDataBase\" autocomplete=\"off\" spellcheck=\"false\" />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-control>\n        <div class=\"dropDBFooter\">\n          <button class=\"drop\" nz-button nzType=\"danger\" [disabled]=\"!dropDataBaseForm.valid || dropDataBaseLoader\"\n            (click)=\"dropDB()\">\n            {{ dropDataBaseLoader ? 'Dropping ...' : 'Drop' }}\n          </button>\n          <button class=\"cancel\" nz-button nzType=\"default\" (click)=\"closeModal('dropDataBase')\">\n            Cancel\n          </button>\n        </div>\n      </nz-form-control>\n    </nz-form-item>\n  </form>\n</nz-modal>\n<nz-modal nzMaskClosable=\"false\" [(nzVisible)]=\"addDB\" nzTitle=\"Add Database\" (nzOnCancel)=\"closeModal('addDB')\"\n  [nzBodyStyle]=\"{height: '257px'}\" [nzFooter]=\"null\">\n  <form nz-form [formGroup]=\"addDBForm\">\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"6\" [nzXs]=\"24\" nzRequired nzFor=\"database\">Database</nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\">\n        <input nz-input formControlName=\"database\" id=\"database\" placeholder=\"Enter a name for the new database\"\n          autocomplete=\"off\" spellcheck=\"false\" />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-label [nzSm]=\"6\" [nzXs]=\"24\" nzFor=\"collection\" nzRequired>Collection</nz-form-label>\n      <nz-form-control [nzSm]=\"14\" [nzXs]=\"24\"\n        nzExtra=\"You need to add at least one collection inorder to work with the new database\">\n        <input nz-input id=\"collection\" formControlName=\"collection\" autocomplete=\"off\"\n          placeholder=\"Enter a name for the new collection\" spellcheck=\"false\" />\n      </nz-form-control>\n    </nz-form-item>\n    <nz-form-item>\n      <nz-form-control>\n        <div class=\"addDBFooter\">\n          <button class=\"add\" nz-button nzType=\"primary\" [disabled]=\"!addDBForm.valid || addDBLoader\"\n            (click)=\"addDataBase()\">\n            {{ addDBLoader ? 'Adding ...' : 'Add' }}\n          </button>\n          <button class=\"cancel\" nz-button nzType=\"default\" (click)=\"closeModal('addDB')\">\n            Cancel\n          </button>\n        </div>\n      </nz-form-control>\n    </nz-form-item>\n  </form>\n</nz-modal>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/collection/collection.component.html":
  /*!********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/collection/collection.component.html ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCollectionCollectionComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<div class=\"tab-content\">\n  <div class=\"help\">\n    <div class=\"bar\">\n      <div class=\"query\">\n        <nz-input-group nzCompact>\n          <nz-select [(ngModel)]=\"searchMode\" style=\"width:15%\">\n            <nz-option nzLabel=\"Simple\" nzValue=\"simple\"></nz-option>\n            <nz-option nzLabel=\"Advanced\" nzValue=\"advanced\"></nz-option>\n          </nz-select>\n          <input type=\"text\" nz-input placeholder=\"Query documents...\" style=\"width:70%;\"\n            *ngIf=\"searchMode === 'advanced'\" (click)=\"openAdvancedSearchForm()\" [(ngModel)]=\"filter\"\n            spellcheck=\"false\" />\n          <input type=\"text\" nz-input placeholder=\"Key\" style=\"width:25%;\" *ngIf=\"searchMode === 'simple'\"\n            [(ngModel)]=\"searchObj.key\" spellcheck=\"false\" />\n          <input type=\"text\" disabled nz-input placeholder=\":\" style=\"width: 4%; pointer-events: none;\"\n            *ngIf=\"searchMode === 'simple'\" />\n          <input type=\"text\" nz-input placeholder=\"Value\" style=\"width:25%;\" *ngIf=\"searchMode === 'simple'\"\n            [(ngModel)]=\"searchObj.value\" spellcheck=\"false\" />\n          <nz-select [(ngModel)]=\"searchObj.type\" style=\"width:16%\" *ngIf=\"searchMode === 'simple'\">\n            <nz-option nzLabel=\"ObjectId\" nzValue=\"ObjectId\"></nz-option>\n            <nz-option nzLabel=\"String\" nzValue=\"String\"></nz-option>\n            <nz-option nzLabel=\"Date\" nzValue=\"Date\"></nz-option>\n            <nz-option nzLabel=\"Number\" nzValue=\"Number\"></nz-option>\n            <nz-option nzLabel=\"Boolean\" nzValue=\"Boolean\"></nz-option>\n          </nz-select>\n          <button nz-button nzType=\"primary\" nzSize=\"medium\" (click)=\"uiQuery()\" style=\"width:15%\">\n            Find\n          </button>\n        </nz-input-group>\n      </div>\n      <div>\n        <nz-tag nzMode=\"closeable\" (nzOnClose)=\"clearFilter()\" *ngIf=\"filter\">Clear search</nz-tag>\n        <nz-button-group>\n          <button nz-button nz-dropdown [nzDropdownMenu]=\"menu\">\n            <i nz-icon nzType=\"download\"></i>Add\n          </button>\n          <nz-dropdown-menu #menu=\"nzDropdownMenu\">\n            <ul nz-menu>\n              <li nz-menu-item (click)=\"showImportModal()\">Import File</li>\n              <nz-modal nzMaskClosable=\"false\" [(nzVisible)]=\"isImportVisible\" nzKeyboard=false nzTitle=\"Import File\"\n                nzWidth=\"650\" nzClosable=false nzCentered (nzOnCancel)=\"closeImportModal()\" [nzContent]=\"importModalContent\">\n                <ng-template #importModalContent>\n                  <nz-upload nzType=\"drag\" [nzBeforeUpload]=\"beforeUpload\"\n                    nzAccept=\".json, .csv\" [nzDisabled]=\"importing\">\n                    <p class=\"ant-upload-drag-icon\">\n                      <i nz-icon nzType=\"inbox\"></i>\n                    </p>\n                    <p class=\"ant-upload-text\">Click or drag file to this area to upload</p>\n                    <p class=\"ant-upload-hint\">\n                      Support for a single upload. Supports only .json, and .csv files.\n                    </p>\n                  </nz-upload>\n                  <div *ngIf=\"file\" class=\"upload\"><i nz-icon style=\"margin-left:5px; margin-right:8px;\" nzType=\"paper-clip\" nzTheme=\"outline\"></i>{{file}}</div>\n                  <div\n                    style=\"background-color: red; color: #fff; height: auto; width: 100%; margin-top: 10px; border-radius: 10px;\"\n                    *ngIf=\"importError\">\n                    <span style=\"padding: 15px;\">{{importError}}</span>\n                  </div>\n                  <div *ngIf=\"file && attributes[0]\" style=\"margin-top: 10px;\">Attributes:</div>\n                  <div *ngIf=\"file && attributes[0]\" class=\"attributes\">\n                    <div *ngFor=\"let attribute of attributes\">\n                      <div style=\"margin-top: 8px;\">\n                        <input type=\"checkbox\" [checked]=\"true\" [(ngModel)]=\"attribute.include\">\n                        <label style=\"padding-left: 10px; padding-right:10px;\">{{attribute.label}}</label>\n                        <select style=\"width:15%;\" [(ngModel)]=\"attribute.type\">\n                          <option label=\"ObjectId\" value=\"ObjectId\"></option>\n                          <option label=\"String\" value=\"String\"></option>\n                          <option label=\"Date\" value=\"Date\"></option>\n                          <option label=\"Number\" value=\"Number\"></option>\n                          <option label=\"Boolean\" value=\"Boolean\"></option>\n                        </select>\n                      </div>\n                    </div>\n                  </div>\n                </ng-template>\n                <div *nzModalFooter>\n                  <button nz-button nzType=\"default\" (click)=\"closeImportModal()\" [disabled]=\"importing\">Close</button>\n                  <button nz-button nzType=\"primary\" (click)=\"importRecords()\" [disabled]=\"!importButton\">{{importing ?\n                    'Importing...' : 'Import'}}</button>\n                </div>\n              </nz-modal>\n              <li nz-menu-item (click)=\"openEditor({}, 'create')\">Insert Document</li>\n            </ul>\n          </nz-dropdown-menu>\n          <button nz-button nzType=\"default\" (click)=\"showExportModal()\" [disabled]=\"!count\">\n            <i nz-icon nzType=\"upload\" nzTheme=\"outline\"></i>Export\n          </button>\n          <nz-modal nzMaskClosable=\"false\" [(nzVisible)]=\"isExportVisible\" nzKeyboard=false nzTitle=\"Export Collection\"\n            nzWidth=\"650\" nzClosable=false nzCentered (nzOnCancel)=\"closeExportModal()\" [nzContent]=\"exportContent\">\n            <ng-template #exportContent>\n              <div style=\"margin-top: 5px; margin-bottom: 5px;\">Export as:</div>\n              <nz-radio-group [(ngModel)]=\"exportAs\" nzName=\"radiogroup\">\n                <label style=\"margin-bottom: 3px;\" nz-radio nzValue=\"json\">JSON</label>\n                <br/>\n                <label style=\"margin-bottom: 3px;\" nz-radio nzValue=\"csv\">CSV</label>\n              </nz-radio-group>\n              <div *ngIf=\"exportAs === 'csv' && attributes[0]\" style=\"margin-top: 5px;\">Attributes:</div>\n              <div style=\"margin-top: 5px; margin-bottom: 5px;\" *ngIf=\"exportAs === 'csv' && attributes[0]\" class=\"attributes\">\n                <div *ngFor=\"let attribute of attributes\">\n                  <div style=\"margin-top: 5px;\">\n                    <input type=\"checkbox\" [checked]=\"true\" [(ngModel)]=\"attribute.include\">\n                    <label style=\"padding-left: 10px; padding-right:10px;\">{{attribute.label}}</label>\n                  </div>\n                </div>\n              </div>\n            </ng-template>\n            <div *nzModalFooter>\n              <button nz-button nzType=\"default\" (click)=\"closeExportModal()\" [disabled]=\"exporting\">Close</button>\n              <button nz-button nzType=\"primary\" (click)=\"exportCollection()\" [disabled]=\"!exportButton\">{{exporting ?\n                'Exporting...' : 'Export'}}</button>\n            </div>\n          </nz-modal>\n          <button nz-button nzType=\"default\" (click)=\"query()\">\n            <i nz-icon nzType=\"reload\"></i>{{ loading ? 'Loading...' : 'Reload' }}\n          </button>\n        </nz-button-group>\n      </div>\n    </div>\n  </div>\n  <div class=\"pagination light-text\">\n    <div class=\"left-child\">\n      {{\n      (database + ' → ' + collection).length > 45\n      ? (database + ' → ' + collection).substring(0, 45) + '...'\n      : database + ' → ' + collection\n      }}\n    </div>\n    <div class=\"right-child\">\n      <nz-pagination [(nzPageIndex)]=\"pageIndex\" [nzTotal]=\"data?.count\" [nzSize]=\"'small'\" [nzPageSize]=\"10\"\n        (nzPageIndexChange)=\"query()\" nzShowQuickJumper=\"true\" [nzShowTotal]=\"renderItemTemplate\"></nz-pagination>\n      <ng-template #renderItemTemplate let-total let-range=\"range\">\n        Displaying {{ range[0] }} - {{ range[1] }} of {{ total }} documents\n      </ng-template>\n    </div>\n  </div>\n  <div class=\"container\">\n    <nz-spin [nzSpinning]=\"loading\" class=\"loader\" [nzIndicator]=\"indicatorTemplate\"></nz-spin>\n    <ng-template #indicatorTemplate><i nz-icon nzType=\"loading\" style=\"font-size: 80px;\"></i>\n    </ng-template>\n    <div *ngFor=\"let doc of data?.documents; let i = index\" class=\"document\">\n      <div class=\"left\">\n        <app-document [data]=\"doc\"></app-document>\n      </div>\n      <div class=\"right\">\n        <button nz-button nzType=\"default\" (click)=\"openEditor(doc, 'update')\" nzTooltipTitle=\"Edit\"\n          nzTooltipPlacement=\"top\" nz-tooltip>\n          <i nz-icon nzType=\"edit\"></i>\n        </button>\n        <div class=\"copy\">\n          <button style=\"margin-bottom: 2px;\" nz-button nzType=\"default\" nzTooltipTitle=\"Copy as\" nzTooltipPlacement=\"top\" nz-tooltip><i nz-icon nzType=\"copy\"></i></button>\n          <ul class=\"copy-as\" style=\"list-style-type: none;\">\n            <li (click)=\"copyToClipboard(doc, 'JSON')\">JSON</li>\n            <li (click)=\"copyToClipboard(doc, 'BSON')\">BSON</li>\n          </ul>\n        </div>\n        <button class=\"spl-button\" nz-button nzType=\"default\" nzTooltipTitle=\"Delete\" nzTooltipPlacement=\"top\"\n          nz-tooltip nz-popconfirm nzPopconfirmTitle=\"Are you sure you want to delete this document?\"\n          (nzOnConfirm)=\"deleteDocument(doc)\" nzPopconfirmPlacement=\"left\">\n          <i nz-icon nzType=\"delete\"></i>\n        </button>\n      </div>\n    </div>\n\n    <nz-empty *ngIf=\"!loading && (!data || !data.documents.length)\"\n      nzNotFoundImage=\"https://gw.alipayobjects.com/zos/antfincdn/ZHrcdLPrvN/empty.svg\"\n      [nzNotFoundContent]=\"contentTpl\">\n      <ng-template #contentTpl>\n        <span> This collection doesn't have any documents </span>\n      </ng-template>\n    </nz-empty>\n  </div>\n</div>\n<nz-drawer [nzBodyStyle]=\"{\n    height: 'calc(100% - 55px)',\n    overflow: 'auto',\n    'padding-bottom': '53px'\n  }\" [nzMaskClosable]=\"true\" [nzWidth]=\"1000\" [nzVisible]=\"showEditor\" [nzTitle]=\"\n    documentEditorMode === 'create' ? 'Add new document' : 'Edit document'\n  \" (nzOnClose)=\"closeEditor()\">\n  <ngx-monaco-editor *ngIf=\"showEditor\" class=\"document-editor\" [options]=\"editorOptions\"\n    [(ngModel)]=\"documentBeingEdited\"></ngx-monaco-editor>\n  <div class=\"footer\">\n    <button type=\"button\" (click)=\"closeEditor()\" class=\"ant-btn\" style=\"margin-right: 8px;\">\n      <span>Cancel</span>\n    </button>\n    <button type=\"button\" (click)=\"updateDocument()\" class=\"ant-btn ant-btn-primary\">\n      <span>{{ documentEditorMode === 'create' ? 'Add' : 'Save' }}</span>\n    </button>\n  </div>\n</nz-drawer>\n\n<nz-modal [(nzVisible)]=\"showAdvancedSearchForm\" nzTitle=\"Query\" (nzOnOk)=\"uiQuery()\"\n  (nzOnCancel)=\"closeAdvancedSearchForm()\" [nzOkLoading]=\"loading\">\n  <ngx-monaco-editor *ngIf=\"showAdvancedSearchForm\" [options]=\"editorOptions\" [(ngModel)]=\"filter\"></ngx-monaco-editor>\n  <a href=\"https://docs.mongodb.com/manual/reference/mongodb-extended-json/index.html#example\" target=\"_blank\">Learn\n    more about querying against ObjectId, Date and other types of fields</a>\n</nz-modal>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/document/document.component.html":
  /*!****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/document/document.component.html ***!
    \****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDocumentDocumentComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ul>\n  <li *ngFor=\"let row of data | keyvalue: originalOrder\">\n    <ng-container [ngSwitch]=\"row.value | type\">\n      <ng-container *ngSwitchCase=\"'String'\">\n        <div class=\"fieldset\" [ngClass]=\"row.value | type\">\n          <div class=\"key\">{{ row.key }}</div>\n          <div class=\"separator\">:</div>\n          <div class=\"value\">{{ row.value | formatValue }}</div>\n          <span\n            (click)=\"showMoreLessText($event, row.value)\"\n            class=\"collapsed toggle\"\n            *ngIf=\"row.value | hasMoreText\"\n          ></span>\n        </div>\n      </ng-container>\n      <ng-container\n        *ngSwitchCase=\"(row.value | isExpandable) ? (row.value | type) : ''\"\n      >\n        <div class=\"fieldset\" [ngClass]=\"row.value | type\">\n          <div class=\"key\">{{ row.key }}</div>\n          <div class=\"separator\">:</div>\n          <div class=\"value meta-data\">{{ row.value | formatValue }}</div>\n        </div>\n        <app-document [data]=\"row.value\"></app-document>\n        <span (click)=\"clicked($event, row)\" class=\"collapsed toggle\"></span>\n      </ng-container>\n      <ng-container *ngSwitchDefault>\n        <div class=\"fieldset\" [ngClass]=\"row.value | type\">\n          <div class=\"key\">{{ row.key }}</div>\n          <div class=\"separator\">:</div>\n          <div class=\"value\">{{ row.value | formatValue }}</div>\n        </div>\n      </ng-container>\n    </ng-container>\n  </li>\n</ul>\n";
    /***/
  },

  /***/
  "./node_modules/tslib/tslib.es6.js":
  /*!*****************************************!*\
    !*** ./node_modules/tslib/tslib.es6.js ***!
    \*****************************************/

  /*! exports provided: __extends, __assign, __rest, __decorate, __param, __metadata, __awaiter, __generator, __exportStar, __values, __read, __spread, __spreadArrays, __await, __asyncGenerator, __asyncDelegator, __asyncValues, __makeTemplateObject, __importStar, __importDefault */

  /***/
  function node_modulesTslibTslibEs6Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__extends", function () {
      return __extends;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__assign", function () {
      return _assign;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__rest", function () {
      return __rest;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__decorate", function () {
      return __decorate;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__param", function () {
      return __param;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__metadata", function () {
      return __metadata;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__awaiter", function () {
      return __awaiter;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__generator", function () {
      return __generator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__exportStar", function () {
      return __exportStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__values", function () {
      return __values;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__read", function () {
      return __read;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spread", function () {
      return __spread;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__spreadArrays", function () {
      return __spreadArrays;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__await", function () {
      return __await;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncGenerator", function () {
      return __asyncGenerator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncDelegator", function () {
      return __asyncDelegator;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__asyncValues", function () {
      return __asyncValues;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__makeTemplateObject", function () {
      return __makeTemplateObject;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importStar", function () {
      return __importStar;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "__importDefault", function () {
      return __importDefault;
    });
    /*! *****************************************************************************
    Copyright (c) Microsoft Corporation. All rights reserved.
    Licensed under the Apache License, Version 2.0 (the "License"); you may not use
    this file except in compliance with the License. You may obtain a copy of the
    License at http://www.apache.org/licenses/LICENSE-2.0
    
    THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
    KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
    WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
    MERCHANTABLITY OR NON-INFRINGEMENT.
    
    See the Apache Version 2.0 License for specific language governing permissions
    and limitations under the License.
    ***************************************************************************** */

    /* global Reflect, Promise */


    var _extendStatics = function extendStatics(d, b) {
      _extendStatics = Object.setPrototypeOf || {
        __proto__: []
      } instanceof Array && function (d, b) {
        d.__proto__ = b;
      } || function (d, b) {
        for (var p in b) {
          if (b.hasOwnProperty(p)) d[p] = b[p];
        }
      };

      return _extendStatics(d, b);
    };

    function __extends(d, b) {
      _extendStatics(d, b);

      function __() {
        this.constructor = d;
      }

      d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    }

    var _assign = function __assign() {
      _assign = Object.assign || function __assign(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
          s = arguments[i];

          for (var p in s) {
            if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
          }
        }

        return t;
      };

      return _assign.apply(this, arguments);
    };

    function __rest(s, e) {
      var t = {};

      for (var p in s) {
        if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
      }

      if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
        if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
      }
      return t;
    }

    function __decorate(decorators, target, key, desc) {
      var c = arguments.length,
          r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
          d;
      if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
        if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
      }
      return c > 3 && r && Object.defineProperty(target, key, r), r;
    }

    function __param(paramIndex, decorator) {
      return function (target, key) {
        decorator(target, key, paramIndex);
      };
    }

    function __metadata(metadataKey, metadataValue) {
      if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
    }

    function __awaiter(thisArg, _arguments, P, generator) {
      return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) {
          try {
            step(generator.next(value));
          } catch (e) {
            reject(e);
          }
        }

        function rejected(value) {
          try {
            step(generator["throw"](value));
          } catch (e) {
            reject(e);
          }
        }

        function step(result) {
          result.done ? resolve(result.value) : new P(function (resolve) {
            resolve(result.value);
          }).then(fulfilled, rejected);
        }

        step((generator = generator.apply(thisArg, _arguments || [])).next());
      });
    }

    function __generator(thisArg, body) {
      var _ = {
        label: 0,
        sent: function sent() {
          if (t[0] & 1) throw t[1];
          return t[1];
        },
        trys: [],
        ops: []
      },
          f,
          y,
          t,
          g;
      return g = {
        next: verb(0),
        "throw": verb(1),
        "return": verb(2)
      }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
        return this;
      }), g;

      function verb(n) {
        return function (v) {
          return step([n, v]);
        };
      }

      function step(op) {
        if (f) throw new TypeError("Generator is already executing.");

        while (_) {
          try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];

            switch (op[0]) {
              case 0:
              case 1:
                t = op;
                break;

              case 4:
                _.label++;
                return {
                  value: op[1],
                  done: false
                };

              case 5:
                _.label++;
                y = op[1];
                op = [0];
                continue;

              case 7:
                op = _.ops.pop();

                _.trys.pop();

                continue;

              default:
                if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                  _ = 0;
                  continue;
                }

                if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                  _.label = op[1];
                  break;
                }

                if (op[0] === 6 && _.label < t[1]) {
                  _.label = t[1];
                  t = op;
                  break;
                }

                if (t && _.label < t[2]) {
                  _.label = t[2];

                  _.ops.push(op);

                  break;
                }

                if (t[2]) _.ops.pop();

                _.trys.pop();

                continue;
            }

            op = body.call(thisArg, _);
          } catch (e) {
            op = [6, e];
            y = 0;
          } finally {
            f = t = 0;
          }
        }

        if (op[0] & 5) throw op[1];
        return {
          value: op[0] ? op[1] : void 0,
          done: true
        };
      }
    }

    function __exportStar(m, exports) {
      for (var p in m) {
        if (!exports.hasOwnProperty(p)) exports[p] = m[p];
      }
    }

    function __values(o) {
      var m = typeof Symbol === "function" && o[Symbol.iterator],
          i = 0;
      if (m) return m.call(o);
      return {
        next: function next() {
          if (o && i >= o.length) o = void 0;
          return {
            value: o && o[i++],
            done: !o
          };
        }
      };
    }

    function __read(o, n) {
      var m = typeof Symbol === "function" && o[Symbol.iterator];
      if (!m) return o;
      var i = m.call(o),
          r,
          ar = [],
          e;

      try {
        while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
          ar.push(r.value);
        }
      } catch (error) {
        e = {
          error: error
        };
      } finally {
        try {
          if (r && !r.done && (m = i["return"])) m.call(i);
        } finally {
          if (e) throw e.error;
        }
      }

      return ar;
    }

    function __spread() {
      for (var ar = [], i = 0; i < arguments.length; i++) {
        ar = ar.concat(__read(arguments[i]));
      }

      return ar;
    }

    function __spreadArrays() {
      for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
        s += arguments[i].length;
      }

      for (var r = Array(s), k = 0, i = 0; i < il; i++) {
        for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
          r[k] = a[j];
        }
      }

      return r;
    }

    ;

    function __await(v) {
      return this instanceof __await ? (this.v = v, this) : new __await(v);
    }

    function __asyncGenerator(thisArg, _arguments, generator) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var g = generator.apply(thisArg, _arguments || []),
          i,
          q = [];
      return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i;

      function verb(n) {
        if (g[n]) i[n] = function (v) {
          return new Promise(function (a, b) {
            q.push([n, v, a, b]) > 1 || resume(n, v);
          });
        };
      }

      function resume(n, v) {
        try {
          step(g[n](v));
        } catch (e) {
          settle(q[0][3], e);
        }
      }

      function step(r) {
        r.value instanceof __await ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
      }

      function fulfill(value) {
        resume("next", value);
      }

      function reject(value) {
        resume("throw", value);
      }

      function settle(f, v) {
        if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
      }
    }

    function __asyncDelegator(o) {
      var i, p;
      return i = {}, verb("next"), verb("throw", function (e) {
        throw e;
      }), verb("return"), i[Symbol.iterator] = function () {
        return this;
      }, i;

      function verb(n, f) {
        i[n] = o[n] ? function (v) {
          return (p = !p) ? {
            value: __await(o[n](v)),
            done: n === "return"
          } : f ? f(v) : v;
        } : f;
      }
    }

    function __asyncValues(o) {
      if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
      var m = o[Symbol.asyncIterator],
          i;
      return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
        return this;
      }, i);

      function verb(n) {
        i[n] = o[n] && function (v) {
          return new Promise(function (resolve, reject) {
            v = o[n](v), settle(resolve, reject, v.done, v.value);
          });
        };
      }

      function settle(resolve, reject, d, v) {
        Promise.resolve(v).then(function (v) {
          resolve({
            value: v,
            done: d
          });
        }, reject);
      }
    }

    function __makeTemplateObject(cooked, raw) {
      if (Object.defineProperty) {
        Object.defineProperty(cooked, "raw", {
          value: raw
        });
      } else {
        cooked.raw = raw;
      }

      return cooked;
    }

    ;

    function __importStar(mod) {
      if (mod && mod.__esModule) return mod;
      var result = {};
      if (mod != null) for (var k in mod) {
        if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
      }
      result["default"] = mod;
      return result;
    }

    function __importDefault(mod) {
      return mod && mod.__esModule ? mod : {
        "default": mod
      };
    }
    /***/

  },

  /***/
  "./src/app/api.service.ts":
  /*!********************************!*\
    !*** ./src/app/api.service.ts ***!
    \********************************/

  /*! exports provided: ApiService */

  /***/
  function srcAppApiServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ApiService", function () {
      return ApiService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../environments/environment */
    "./src/environments/environment.ts");

    var ApiService = /*#__PURE__*/function () {
      function ApiService(http) {
        _classCallCheck(this, ApiService);

        this.http = http;
        this.apiRoot = _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].apiRoot;
        this.BASE_URL = "".concat(this.apiRoot, "/databases");
      }

      _createClass(ApiService, [{
        key: "getDbs",
        value: function getDbs() {
          return this.http.get("".concat(this.BASE_URL, "?includeCollections=true"));
        }
      }, {
        key: "getCollections",
        value: function getCollections(dbName) {
          return this.http.get("".concat(this.BASE_URL, "/").concat(dbName, "/collections"));
        }
      }, {
        key: "getDocumentsByCollection",
        value: function getDocumentsByCollection(dbName, collectionName) {
          return this.http.get("".concat(this.BASE_URL, "/").concat(dbName, "/collections/").concat(collectionName, "/documents?limit=10&ContentType=ejson"));
        }
      }, {
        key: "filterDocumentsByQuery",
        value: function filterDocumentsByQuery(dbName, collectionName, query) {
          var pageIndex = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : 1;
          return this.http.post("".concat(this.BASE_URL, "/").concat(dbName, "/collections/").concat(collectionName, "/documents/filter?limit=10&skip=").concat((pageIndex - 1) * 10, "&ContentType=ejson&incomingType=ejson"), query);
        }
      }, {
        key: "getDocumentCount",
        value: function getDocumentCount(dbName, collectionName, query) {
          return this.http.post("".concat(this.BASE_URL, "/").concat(dbName, "/collections/").concat(collectionName, "/documents/count?incomingType=ejson&ContentType=ejson"), query);
        }
      }, {
        key: "deleteDocumentById",
        value: function deleteDocumentById(dbName, collectionName, document) {
          return this.http.post("".concat(this.BASE_URL, "/").concat(dbName, "/collections/").concat(collectionName, "/documents/delete?incomingType=ejson"), document);
        } // updateDocument(dbName, collectionName, document) {
        //   return this.http.put(
        //     `${this.BASE_URL}/${dbName}/collections/${collectionName}/documents?incomingType=ejson`,
        //     document
        //   );
        // }
        // createDocument(dbName, collectionName, document) {
        //   return this.http.post(
        //     `${this.BASE_URL}/${dbName}/collections/${collectionName}/documents?incomingType=ejson`,
        //     document
        //   );
        // }

      }, {
        key: "createDocuments",
        value: function createDocuments(dbName, collectionName, document) {
          return this.http.post("".concat(this.BASE_URL, "/").concat(dbName, "/collections/").concat(collectionName, "/documents?incomingType=ejson"), document);
        }
      }, {
        key: "createCollection",
        value: function createCollection(body) {
          return this.http.post("".concat(this.BASE_URL, "/").concat(body.database, "/collections"), body);
        }
      }, {
        key: "dropCollection",
        value: function dropCollection(body) {
          return this.http.post("".concat(this.BASE_URL, "/").concat(body.database, "/collections/delete"), body);
        }
      }, {
        key: "dropDB",
        value: function dropDB(body) {
          return this.http["delete"]("".concat(this.BASE_URL, "/").concat(body.database));
        }
      }, {
        key: "aggregate",
        value: function aggregate(dbName, collectionName, query) {
          return this.http.post("".concat(this.BASE_URL, "/").concat(dbName, "/collections/").concat(collectionName, "/documents/aggregate?ContentType=ejson&incomingType=ejson"), query);
        }
      }]);

      return ApiService;
    }();

    ApiService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    ApiService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], ApiService);
    /***/
  },

  /***/
  "./src/app/app-routing.module.ts":
  /*!***************************************!*\
    !*** ./src/app/app-routing.module.ts ***!
    \***************************************/

  /*! exports provided: AppRoutingModule */

  /***/
  function srcAppAppRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function () {
      return AppRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var routes = [];

    var AppRoutingModule = function AppRoutingModule() {
      _classCallCheck(this, AppRoutingModule);
    };

    AppRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AppRoutingModule);
    /***/
  },

  /***/
  "./src/app/app.component.css":
  /*!***********************************!*\
    !*** ./src/app/app.component.css ***!
    \***********************************/

  /*! exports provided: default */

  /***/
  function srcAppAppComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".logo {\n  height: 32px;\n  margin: 16px;\n}\n\n.left-layout {\n  height: 100vh;\n}\n\nnz-sider {\n  height: 100%;\n  position: fixed;\n  left: 0;\n  background-color: #41545d !important;\n  /* font-family: 'Lato', sans-serif !important; */\n}\n\n.right-layout {\n  margin-left: 300px;\n}\n\nnz-header {\n  background: #fff;\n  padding: 0;\n}\n\nnz-content {\n  overflow: hidden;\n  background: #fff;\n}\n\n.inner-content {\n  padding: 24px;\n  background: #fff;\n  text-align: center;\n}\n\nnz-footer {\n  text-align: center;\n}\n\n/* sidenav */\n\n.menu,\n.menu li ul {\n  padding: 0;\n  color: #f5f5f5 !important;\n}\n\n.menu .nav_item:hover {\n  background-color: #607d8b;\n}\n\n.menu li {\n  list-style-type: none !important;\n}\n\n.nav_item {\n  padding: 2px 18px;\n  color: #c4c5c5;\n}\n\n.nav_item:hover {\n  cursor: pointer;\n  border-radius: 0.15em;\n  box-sizing: border-box;\n  text-decoration: none;\n  color: #c6c6c6;\n  background-color: green;\n  box-shadow: inset 0 -0.6em 0 -0.35em rgba(0, 0, 0, 0.17);\n}\n\n.menu li ul {\n  display: none;\n}\n\n.open + ul {\n  display: block !important;\n}\n\n.db_item::before {\n  content: '\\276F';\n  line-height: 20px;\n  position: relative;\n  left: -5px;\n}\n\n.collection_item {\n  padding-left: 28px;\n}\n\n.collection_item a {\n  color: #c4c5c5 !important;\n}\n\n.db_item.open::before {\n  content: '\\276F';\n  display: inline-block;\n  transform: rotate(90deg);\n}\n\n.side_top {\n  height: 100px;\n}\n\n.side_explorer {\n  max-height: 500px;\n  overflow-y: auto;\n}\n\n.nav_item .action {\n  display: none;\n  float: right;\n}\n\n.nav_item:hover .action {\n  display: block;\n}\n\n.action span {\n  padding: 0px 2px;\n}\n\n/* App title */\n\n.title {\n  padding: 15px 5px;\n}\n\n.title h2:hover {\n  cursor: pointer;\n}\n\n.title h2 {\n  /* font-style: italic; */\n  font-family: none;\n  /* text-align: center; */\n  color: #c4c4c4;\n  /* text-decoration: underline; */\n  /* text-decoration-thickness: 200; */\n}\n\n.dashboard-stats {\n  padding: 15px;\n  padding-bottom: 0px;\n}\n\n.collection-stats {\n  padding: 15px;\n  padding-bottom: 0px;\n}\n\n/* search box */\n\n.search {\n  height: 28px;\n  width: 100%;\n  background-color: #335c67;\n  border: none;\n  color: #fff;\n  outline: none;\n}\n\n.search:focus {\n  outline: none;\n  box-shadow: none;\n}\n\n.search-box {\n  padding: 0px;\n  box-sizing: border-box;\n  outline: none;\n}\n\n/* reload-dbs-btn */\n\n.reload-dbs-btn {\n  color: #c4c4c4;\n  cursor: pointer;\n  font-size: smaller;\n}\n\n.reload-dbs-btn:hover {\n  color: #c2c2c2;\n}\n\n.add {\n  float: right;\n  margin-top: -12.5px;\n}\n\n.drop {\n  float: right;\n  margin-top: -12.5px;\n}\n\n.cancel {\n  float: right;\n  margin-top: -12.5px;\n  margin-right: 15px;\n}\n\n.addTableFooter {\n  width: 110.2%;\n  margin-left: -24px;\n  border: 1px solid #e8e8e8;\n  border-radius: 0px 0px 4px 4px;\n  padding: 30px;\n}\n\n.dropTableFooter {\n  width: 110.2%;\n  margin-left: -24px;\n  border: 1px solid #e8e8e8;\n  border-radius: 0px 0px 4px 4px;\n  padding: 30px;\n}\n\n.dropDBFooter {\n  width: 110.2%;\n  margin-left: -24px;\n  border: 1px solid #e8e8e8;\n  border-radius: 0px 0px 4px 4px;\n  padding: 30px;\n}\n\n.addDBFooter {\n  width: 110.2%;\n  margin-left: -24px;\n  border: 1px solid #e8e8e8;\n  border-radius: 0px 0px 4px 4px;\n  padding: 30px;\n}\n\n.drop-db, .drop-table {\n  visibility: hidden;\n}\n\ntr:hover .drop-db, tr:hover .drop-table {\n  visibility: visible;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYXBwLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxZQUFZO0VBQ1osWUFBWTtBQUNkOztBQUVBO0VBQ0UsYUFBYTtBQUNmOztBQUVBO0VBQ0UsWUFBWTtFQUNaLGVBQWU7RUFDZixPQUFPO0VBQ1Asb0NBQW9DO0VBQ3BDLGdEQUFnRDtBQUNsRDs7QUFFQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLGdCQUFnQjtFQUNoQixVQUFVO0FBQ1o7O0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsZ0JBQWdCO0FBQ2xCOztBQUVBO0VBQ0UsYUFBYTtFQUNiLGdCQUFnQjtFQUNoQixrQkFBa0I7QUFDcEI7O0FBRUE7RUFDRSxrQkFBa0I7QUFDcEI7O0FBRUEsWUFBWTs7QUFDWjs7RUFFRSxVQUFVO0VBQ1YseUJBQXlCO0FBQzNCOztBQUNBO0VBQ0UseUJBQXlCO0FBQzNCOztBQUNBO0VBQ0UsZ0NBQWdDO0FBQ2xDOztBQUNBO0VBQ0UsaUJBQWlCO0VBQ2pCLGNBQWM7QUFDaEI7O0FBQ0E7RUFDRSxlQUFlO0VBQ2YscUJBQXFCO0VBQ3JCLHNCQUFzQjtFQUN0QixxQkFBcUI7RUFDckIsY0FBYztFQUNkLHVCQUF1QjtFQUN2Qix3REFBd0Q7QUFDMUQ7O0FBQ0E7RUFDRSxhQUFhO0FBQ2Y7O0FBQ0E7RUFDRSx5QkFBeUI7QUFDM0I7O0FBQ0E7RUFDRSxnQkFBZ0I7RUFDaEIsaUJBQWlCO0VBQ2pCLGtCQUFrQjtFQUNsQixVQUFVO0FBQ1o7O0FBQ0E7RUFDRSxrQkFBa0I7QUFDcEI7O0FBQ0E7RUFDRSx5QkFBeUI7QUFDM0I7O0FBQ0E7RUFDRSxnQkFBZ0I7RUFDaEIscUJBQXFCO0VBSXJCLHdCQUF3QjtBQUMxQjs7QUFDQTtFQUNFLGFBQWE7QUFDZjs7QUFDQTtFQUNFLGlCQUFpQjtFQUNqQixnQkFBZ0I7QUFDbEI7O0FBQ0E7RUFDRSxhQUFhO0VBQ2IsWUFBWTtBQUNkOztBQUNBO0VBQ0UsY0FBYztBQUNoQjs7QUFDQTtFQUNFLGdCQUFnQjtBQUNsQjs7QUFFQSxjQUFjOztBQUNkO0VBQ0UsaUJBQWlCO0FBQ25COztBQUNBO0VBQ0UsZUFBZTtBQUNqQjs7QUFDQTtFQUNFLHdCQUF3QjtFQUN4QixpQkFBaUI7RUFDakIsd0JBQXdCO0VBQ3hCLGNBQWM7RUFDZCxnQ0FBZ0M7RUFDaEMsb0NBQW9DO0FBQ3RDOztBQUNBO0VBQ0UsYUFBYTtFQUNiLG1CQUFtQjtBQUNyQjs7QUFFQTtFQUNFLGFBQWE7RUFDYixtQkFBbUI7QUFDckI7O0FBRUEsZUFBZTs7QUFDZjtFQUNFLFlBQVk7RUFDWixXQUFXO0VBQ1gseUJBQXlCO0VBQ3pCLFlBQVk7RUFDWixXQUFXO0VBQ1gsYUFBYTtBQUNmOztBQUNBO0VBQ0UsYUFBYTtFQUNiLGdCQUFnQjtBQUNsQjs7QUFDQTtFQUNFLFlBQVk7RUFDWixzQkFBc0I7RUFDdEIsYUFBYTtBQUNmOztBQUVBLG1CQUFtQjs7QUFDbkI7RUFDRSxjQUFjO0VBQ2QsZUFBZTtFQUNmLGtCQUFrQjtBQUNwQjs7QUFDQTtFQUNFLGNBQWM7QUFDaEI7O0FBQ0E7RUFDRSxZQUFZO0VBQ1osbUJBQW1CO0FBQ3JCOztBQUNBO0VBQ0UsWUFBWTtFQUNaLG1CQUFtQjtBQUNyQjs7QUFDQTtFQUNFLFlBQVk7RUFDWixtQkFBbUI7RUFDbkIsa0JBQWtCO0FBQ3BCOztBQUNBO0VBQ0UsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQix5QkFBeUI7RUFDekIsOEJBQThCO0VBQzlCLGFBQWE7QUFDZjs7QUFDQTtFQUNFLGFBQWE7RUFDYixrQkFBa0I7RUFDbEIseUJBQXlCO0VBQ3pCLDhCQUE4QjtFQUM5QixhQUFhO0FBQ2Y7O0FBQ0E7RUFDRSxhQUFhO0VBQ2Isa0JBQWtCO0VBQ2xCLHlCQUF5QjtFQUN6Qiw4QkFBOEI7RUFDOUIsYUFBYTtBQUNmOztBQUNBO0VBQ0UsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQix5QkFBeUI7RUFDekIsOEJBQThCO0VBQzlCLGFBQWE7QUFDZjs7QUFFQTtFQUNFLGtCQUFrQjtBQUNwQjs7QUFFQTtFQUNFLG1CQUFtQjtBQUNyQiIsImZpbGUiOiJzcmMvYXBwL2FwcC5jb21wb25lbnQuY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLmxvZ28ge1xuICBoZWlnaHQ6IDMycHg7XG4gIG1hcmdpbjogMTZweDtcbn1cblxuLmxlZnQtbGF5b3V0IHtcbiAgaGVpZ2h0OiAxMDB2aDtcbn1cblxubnotc2lkZXIge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHBvc2l0aW9uOiBmaXhlZDtcbiAgbGVmdDogMDtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzQxNTQ1ZCAhaW1wb3J0YW50O1xuICAvKiBmb250LWZhbWlseTogJ0xhdG8nLCBzYW5zLXNlcmlmICFpbXBvcnRhbnQ7ICovXG59XG5cbi5yaWdodC1sYXlvdXQge1xuICBtYXJnaW4tbGVmdDogMzAwcHg7XG59XG5cbm56LWhlYWRlciB7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHBhZGRpbmc6IDA7XG59XG5cbm56LWNvbnRlbnQge1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG4uaW5uZXItY29udGVudCB7XG4gIHBhZGRpbmc6IDI0cHg7XG4gIGJhY2tncm91bmQ6ICNmZmY7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cblxubnotZm9vdGVyIHtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xufVxuXG4vKiBzaWRlbmF2ICovXG4ubWVudSxcbi5tZW51IGxpIHVsIHtcbiAgcGFkZGluZzogMDtcbiAgY29sb3I6ICNmNWY1ZjUgIWltcG9ydGFudDtcbn1cbi5tZW51IC5uYXZfaXRlbTpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6ICM2MDdkOGI7XG59XG4ubWVudSBsaSB7XG4gIGxpc3Qtc3R5bGUtdHlwZTogbm9uZSAhaW1wb3J0YW50O1xufVxuLm5hdl9pdGVtIHtcbiAgcGFkZGluZzogMnB4IDE4cHg7XG4gIGNvbG9yOiAjYzRjNWM1O1xufVxuLm5hdl9pdGVtOmhvdmVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBib3JkZXItcmFkaXVzOiAwLjE1ZW07XG4gIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgY29sb3I6ICNjNmM2YzY7XG4gIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xuICBib3gtc2hhZG93OiBpbnNldCAwIC0wLjZlbSAwIC0wLjM1ZW0gcmdiYSgwLCAwLCAwLCAwLjE3KTtcbn1cbi5tZW51IGxpIHVsIHtcbiAgZGlzcGxheTogbm9uZTtcbn1cbi5vcGVuICsgdWwge1xuICBkaXNwbGF5OiBibG9jayAhaW1wb3J0YW50O1xufVxuLmRiX2l0ZW06OmJlZm9yZSB7XG4gIGNvbnRlbnQ6ICdcXDI3NkYnO1xuICBsaW5lLWhlaWdodDogMjBweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBsZWZ0OiAtNXB4O1xufVxuLmNvbGxlY3Rpb25faXRlbSB7XG4gIHBhZGRpbmctbGVmdDogMjhweDtcbn1cbi5jb2xsZWN0aW9uX2l0ZW0gYSB7XG4gIGNvbG9yOiAjYzRjNWM1ICFpbXBvcnRhbnQ7XG59XG4uZGJfaXRlbS5vcGVuOjpiZWZvcmUge1xuICBjb250ZW50OiAnXFwyNzZGJztcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAtd2Via2l0LXRyYW5zZm9ybTogcm90YXRlKDQwZGVnKTtcbiAgLW1vei10cmFuc2Zvcm06IHJvdGF0ZSg0MGRlZyk7XG4gIC1vLXRyYW5zZm9ybTogcm90YXRlKDQwZGVnKTtcbiAgdHJhbnNmb3JtOiByb3RhdGUoOTBkZWcpO1xufVxuLnNpZGVfdG9wIHtcbiAgaGVpZ2h0OiAxMDBweDtcbn1cbi5zaWRlX2V4cGxvcmVyIHtcbiAgbWF4LWhlaWdodDogNTAwcHg7XG4gIG92ZXJmbG93LXk6IGF1dG87XG59XG4ubmF2X2l0ZW0gLmFjdGlvbiB7XG4gIGRpc3BsYXk6IG5vbmU7XG4gIGZsb2F0OiByaWdodDtcbn1cbi5uYXZfaXRlbTpob3ZlciAuYWN0aW9uIHtcbiAgZGlzcGxheTogYmxvY2s7XG59XG4uYWN0aW9uIHNwYW4ge1xuICBwYWRkaW5nOiAwcHggMnB4O1xufVxuXG4vKiBBcHAgdGl0bGUgKi9cbi50aXRsZSB7XG4gIHBhZGRpbmc6IDE1cHggNXB4O1xufVxuLnRpdGxlIGgyOmhvdmVyIHtcbiAgY3Vyc29yOiBwb2ludGVyO1xufVxuLnRpdGxlIGgyIHtcbiAgLyogZm9udC1zdHlsZTogaXRhbGljOyAqL1xuICBmb250LWZhbWlseTogbm9uZTtcbiAgLyogdGV4dC1hbGlnbjogY2VudGVyOyAqL1xuICBjb2xvcjogI2M0YzRjNDtcbiAgLyogdGV4dC1kZWNvcmF0aW9uOiB1bmRlcmxpbmU7ICovXG4gIC8qIHRleHQtZGVjb3JhdGlvbi10aGlja25lc3M6IDIwMDsgKi9cbn1cbi5kYXNoYm9hcmQtc3RhdHMge1xuICBwYWRkaW5nOiAxNXB4O1xuICBwYWRkaW5nLWJvdHRvbTogMHB4O1xufVxuXG4uY29sbGVjdGlvbi1zdGF0cyB7XG4gIHBhZGRpbmc6IDE1cHg7XG4gIHBhZGRpbmctYm90dG9tOiAwcHg7XG59XG5cbi8qIHNlYXJjaCBib3ggKi9cbi5zZWFyY2gge1xuICBoZWlnaHQ6IDI4cHg7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLWNvbG9yOiAjMzM1YzY3O1xuICBib3JkZXI6IG5vbmU7XG4gIGNvbG9yOiAjZmZmO1xuICBvdXRsaW5lOiBub25lO1xufVxuLnNlYXJjaDpmb2N1cyB7XG4gIG91dGxpbmU6IG5vbmU7XG4gIGJveC1zaGFkb3c6IG5vbmU7XG59XG4uc2VhcmNoLWJveCB7XG4gIHBhZGRpbmc6IDBweDtcbiAgYm94LXNpemluZzogYm9yZGVyLWJveDtcbiAgb3V0bGluZTogbm9uZTtcbn1cblxuLyogcmVsb2FkLWRicy1idG4gKi9cbi5yZWxvYWQtZGJzLWJ0biB7XG4gIGNvbG9yOiAjYzRjNGM0O1xuICBjdXJzb3I6IHBvaW50ZXI7XG4gIGZvbnQtc2l6ZTogc21hbGxlcjtcbn1cbi5yZWxvYWQtZGJzLWJ0bjpob3ZlciB7XG4gIGNvbG9yOiAjYzJjMmMyO1xufVxuLmFkZCB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogLTEyLjVweDtcbn1cbi5kcm9wIHtcbiAgZmxvYXQ6IHJpZ2h0O1xuICBtYXJnaW4tdG9wOiAtMTIuNXB4O1xufVxuLmNhbmNlbCB7XG4gIGZsb2F0OiByaWdodDtcbiAgbWFyZ2luLXRvcDogLTEyLjVweDtcbiAgbWFyZ2luLXJpZ2h0OiAxNXB4O1xufVxuLmFkZFRhYmxlRm9vdGVyIHtcbiAgd2lkdGg6IDExMC4yJTtcbiAgbWFyZ2luLWxlZnQ6IC0yNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xuICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDRweCA0cHg7XG4gIHBhZGRpbmc6IDMwcHg7XG59XG4uZHJvcFRhYmxlRm9vdGVyIHtcbiAgd2lkdGg6IDExMC4yJTtcbiAgbWFyZ2luLWxlZnQ6IC0yNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xuICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDRweCA0cHg7XG4gIHBhZGRpbmc6IDMwcHg7XG59XG4uZHJvcERCRm9vdGVyIHtcbiAgd2lkdGg6IDExMC4yJTtcbiAgbWFyZ2luLWxlZnQ6IC0yNHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjZThlOGU4O1xuICBib3JkZXItcmFkaXVzOiAwcHggMHB4IDRweCA0cHg7XG4gIHBhZGRpbmc6IDMwcHg7XG59XG4uYWRkREJGb290ZXIge1xuICB3aWR0aDogMTEwLjIlO1xuICBtYXJnaW4tbGVmdDogLTI0cHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNlOGU4ZTg7XG4gIGJvcmRlci1yYWRpdXM6IDBweCAwcHggNHB4IDRweDtcbiAgcGFkZGluZzogMzBweDtcbn1cblxuLmRyb3AtZGIsIC5kcm9wLXRhYmxlIHtcbiAgdmlzaWJpbGl0eTogaGlkZGVuO1xufVxuXG50cjpob3ZlciAuZHJvcC1kYiwgdHI6aG92ZXIgLmRyb3AtdGFibGUge1xuICB2aXNpYmlsaXR5OiB2aXNpYmxlO1xufVxuIl19 */";
    /***/
  },

  /***/
  "./src/app/app.component.ts":
  /*!**********************************!*\
    !*** ./src/app/app.component.ts ***!
    \**********************************/

  /*! exports provided: AppComponent */

  /***/
  function srcAppAppComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppComponent", function () {
      return AppComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! lodash */
    "./node_modules/lodash/lodash.js");
    /* harmony import */


    var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);

    var AppComponent = /*#__PURE__*/function () {
      // constrcutor
      function AppComponent(Api, fb) {
        _classCallCheck(this, AppComponent);

        this.Api = Api;
        this.fb = fb;
        this.title = 'ui';
        this.activeTabIndex = 0;
        this.dbs = {
          totalSize: 0,
          databases: []
        };
        this.isLoadingDbs = false;
        this.isInSearchMode = false;
        this.stats = {
          databases: 0,
          collections: 0,
          size: 0
        };
        /* tab related operations */

        this.tabs = [];
        /* collection related operations */
        // create new collection

        this.addTableLoader = false; // drop collection

        this.dropTableLoader = false; // drop database

        this.dropDataBaseLoader = false; // add database

        this.addDBLoader = false;
        /* methods to open & close Modals */

        this.addDB = false;
        this.addTable = false;
        this.dropTable = false;
        this.dropDataBase = false;
        this.active = 'databases';
      }
      /* side-nav */


      _createClass(AppComponent, [{
        key: "getDatabases",
        value: function getDatabases() {
          var _this = this;

          this.isLoadingDbs = true;
          this.Api.getDbs().subscribe(function (res) {
            _this.dbs = res;

            _this.computeStats();

            _this.filter();

            if (_this.active === 'collections') _this.showCollections(_this.db);
          }).add(function () {
            _this.isLoadingDbs = false;
          });
        }
      }, {
        key: "reloadSideNav",
        value: function reloadSideNav() {
          this.getDatabases();
        }
      }, {
        key: "computeStats",
        value: function computeStats() {
          this.stats.databases = this.dbs.databases.length;
          this.stats.collections = this.dbs.databases.reduce(function (count, db) {
            return count + db.collections.length;
          }, 0);
          this.stats.size = this.dbs.totalSize;
        }
      }, {
        key: "mustMatch",
        value: function mustMatch(controlName, matchingControlName) {
          return function (formGroup) {
            var control = formGroup.controls[controlName];
            var matchingControl = formGroup.controls[matchingControlName];

            if (matchingControl.errors && !matchingControl.errors.confirmedValidator) {
              return;
            }

            if (control.value !== matchingControl.value) {
              matchingControl.setErrors({
                confirmedValidator: true
              });
            } else {
              matchingControl.setErrors(null);
            }
          };
        }
      }, {
        key: "initForms",
        value: function initForms() {
          this.addTableForm = this.fb.group({
            database: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            collection: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]]
          });
          this.addDBForm = this.fb.group({
            database: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            collection: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]]
          });
          this.dropTableForm = this.fb.group({
            database: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            collection: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            confirmCollection: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]]
          }, {
            validators: this.mustMatch('collection', 'confirmCollection')
          });
          this.dropDataBaseForm = this.fb.group({
            database: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]],
            confirmDataBase: [null, [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]]
          }, {
            validators: this.mustMatch('database', 'confirmDataBase')
          });
        }
      }, {
        key: "ngOnInit",
        value: function ngOnInit() {
          this.getDatabases();
          this.initForms();
        }
      }, {
        key: "expand",
        value: function expand(e, database) {
          if (Object(lodash__WEBPACK_IMPORTED_MODULE_4__["includes"])(e.target.classList, 'collection_item')) return;
          this.closeAllTabs();
          e.stopPropagation();
          e.target.classList.toggle('open');
          this.showCollections(database);
        }
      }, {
        key: "filter",
        value: function filter() {
          this.isInSearchMode = true;
          this.menuData = Object(lodash__WEBPACK_IMPORTED_MODULE_4__["cloneDeep"])(this.dbs.databases);

          if (!this.searchText) {
            this.isInSearchMode = false;
            return;
          }

          var pattern = new RegExp(".*".concat(this.searchText, ".*"), 'i');
          this.menuData = this.menuData.map(function (db) {
            db.collections = db.collections.filter(function (col) {
              return pattern.test(col.name);
            });
            return db;
          }).filter(function (db) {
            return db.collections.length;
          });
        }
      }, {
        key: "activateTab",
        value: function activateTab(index) {
          this.activeTabIndex = index;
        }
      }, {
        key: "openTab",
        value: function openTab(database, collection) {
          var id = "".concat(database, ".").concat(collection);
          var tabIndex = this.tabs.findIndex(function (tab) {
            return tab.id === id;
          });

          if (tabIndex > -1) {
            this.activateTab(tabIndex);
            return;
          }

          this.tabs.push({
            id: id,
            database: database,
            collection: collection
          });
          this.activateTab(this.tabs.length - 1);
        }
      }, {
        key: "closeTab",
        value: function closeTab(id) {
          this.active = 'databases';
          var idx = this.tabs.findIndex(function (tab) {
            return tab.id === id;
          });
          this.tabs.splice(idx, 1);

          if (this.tabs.length) {
            this.activeTabIndex = this.tabs.length - 1;
          }
        }
      }, {
        key: "showCollections",
        value: function showCollections(database) {
          var _this2 = this;

          this.Api.getCollections(database.name).subscribe(function (res) {
            Object(lodash__WEBPACK_IMPORTED_MODULE_4__["set"])(database, 'collections', res);
            _this2.db = database;
            _this2.active = 'collections';
          });
        }
      }, {
        key: "closeTabsByDataBase",
        value: function closeTabsByDataBase(database) {
          this.tabs = this.tabs.filter(function (tab) {
            return tab.database !== database;
          });
        }
      }, {
        key: "closeAllTabs",
        value: function closeAllTabs() {
          this.tabs = [];
        }
      }, {
        key: "openDashBoard",
        value: function openDashBoard() {
          this.active = 'databases';
          this.closeAllTabs();
        }
      }, {
        key: "createTable",
        value: function createTable() {
          var _this3 = this;

          if (!this.addTableForm.valid) {
            return;
          }

          this.addTableLoader = true;
          var body = this.addTableForm.value;
          this.Api.createCollection(body).subscribe(function () {
            _this3.getDatabases(); // re-renders side nav


            _this3.openTab(body.database, body.collection);

            _this3.closeModal('addTable');
          }).add(function () {
            _this3.addTableLoader = false;
          });
        }
      }, {
        key: "dropCollection",
        value: function dropCollection() {
          var _this4 = this;

          if (!this.dropTableForm.valid) {
            return;
          }

          this.dropTableLoader = true;
          var body = this.dropTableForm.value;
          this.Api.dropCollection(body).subscribe(function () {
            _this4.getDatabases(); // re-render side nav


            _this4.closeTab("".concat(body.database, ".").concat(body.collection));

            _this4.closeModal('dropTable');
          }).add(function () {
            _this4.dropTableLoader = false;
          });
        }
      }, {
        key: "dropDB",
        value: function dropDB() {
          var _this5 = this;

          if (!this.dropDataBaseForm.valid) {
            return;
          }

          this.dropDataBaseLoader = true;
          var body = this.dropDataBaseForm.value;
          this.Api.dropDB(body).subscribe(function () {
            _this5.getDatabases(); // re-render side-nav


            _this5.closeTabsByDataBase(body.database);

            _this5.closeModal('dropDataBase');
          }).add(function () {
            _this5.dropDataBaseLoader = false;
          });
        }
      }, {
        key: "addDataBase",
        value: function addDataBase() {
          var _this6 = this;

          if (!this.addDBForm.valid) {
            return;
          }

          this.addDBLoader = true;
          var body = this.addDBForm.value;
          this.Api.createCollection(body).subscribe(function () {
            _this6.getDatabases(); // re-render side-nav


            _this6.openTab(body.database, body.collection);

            _this6.closeModal('addDB');
          }).add(function () {
            _this6.addDBLoader = false;
          });
        }
      }, {
        key: "closeModal",
        value: function closeModal(title) {
          this[title] = false;
        }
      }, {
        key: "openModal",
        value: function openModal(title, options) {
          // initializes values
          if (title === 'addTable') {
            this.addTableForm.reset();
            this.addTableForm.controls.database.setValue(options.database);
          }

          if (title === 'addDB') {
            this.addDBForm.reset();
          }

          if (title === 'dropTable') {
            this.dropTableForm.reset();
            this.dropTableForm.controls.database.setValue(options.database);
            this.dropTableForm.controls.collection.setValue(options.collection);
          }

          if (title === 'dropDataBase') {
            this.dropDataBaseForm.reset();
            this.dropDataBaseForm.controls.database.setValue(options.database);
          } // opens modal


          this[title] = true;
        }
      }]);

      return AppComponent;
    }();

    AppComponent.ctorParameters = function () {
      return [{
        type: _api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
      }, {
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
      }];
    };

    AppComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-root',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./app.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./app.component.css */
      "./src/app/app.component.css"))["default"]]
    })], AppComponent);
    /***/
  },

  /***/
  "./src/app/app.module.ts":
  /*!*******************************!*\
    !*** ./src/app/app.module.ts ***!
    \*******************************/

  /*! exports provided: AppModule */

  /***/
  function srcAppAppModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AppModule", function () {
      return AppModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/platform-browser */
    "./node_modules/@angular/platform-browser/fesm2015/platform-browser.js");
    /* harmony import */


    var _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser/animations */
    "./node_modules/@angular/platform-browser/fesm2015/animations.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _app_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./app-routing.module */
    "./src/app/app-routing.module.ts");
    /* harmony import */


    var _app_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./app.component */
    "./src/app/app.component.ts");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/fesm2015/http.js");
    /* harmony import */


    var _document_document_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./document/document.component */
    "./src/app/document/document.component.ts");
    /* harmony import */


    var _collection_collection_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./collection/collection.component */
    "./src/app/collection/collection.component.ts");
    /* harmony import */


    var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(
    /*! ng-zorro-antd */
    "./node_modules/ng-zorro-antd/fesm2015/ng-zorro-antd.js");
    /* harmony import */


    var _common_pipes_pipes__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(
    /*! ./common/pipes/pipes */
    "./src/app/common/pipes/pipes.ts");
    /* harmony import */


    var _common_pipes_file_size_pipe__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(
    /*! ./common/pipes/file-size.pipe */
    "./src/app/common/pipes/file-size.pipe.ts");
    /* harmony import */


    var _common_interceptors_http_error_interceptor__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(
    /*! ./common/interceptors/http-error.interceptor */
    "./src/app/common/interceptors/http-error.interceptor.ts");
    /* harmony import */


    var ngx_monaco_editor__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(
    /*! ngx-monaco-editor */
    "./node_modules/ngx-monaco-editor/fesm2015/ngx-monaco-editor.js"); // const editorConif : NgxMonacoEditorConfig = {
    //   onMonacoLoad: () => {
    //     monaco.languages.register({ id: 'bson' });
    //     monaco.editor.defineTheme('bson', {
    //       base: 'vs',
    //       inherit: false,
    //       rules: [
    //         { token: 'ObjectId', foreground: 'ff0000' },
    //         { token: 'String', foreground: '872322' },
    //         { token: 'Number', foreground: 'FFA500' }
    //       ],
    //       colors: undefined
    //     });
    //     monaco.languages.setLanguageConfiguration('bson', {
    //       autoClosingPairs: [{open: '{', close: '}'},{open: '(', close: ')'}],
    //       autoCloseBefore: 'a',
    //       folding: {
    //         markers: {
    //           start: /^{/,
    //           end: /}/,
    //         },
    //         offSide: true
    //       },
    //       brackets: [['{', '}'], ['(', ')']],
    //     });
    //     monaco.languages.registerCompletionItemProvider('bson', {
    //       provideCompletionItems: (model, position, context, token) => {
    //         const word = model.getWordUntilPosition(position);
    //         const suggestions : monaco.languages.CompletionItem[] = [{
    //           label: 'ObjectId',
    // 		    	kind: monaco.languages.CompletionItemKind.Keyword,
    // 			    insertText: 'ObjectId("${1}")',
    //           insertTextRules: monaco.languages.CompletionItemInsertTextRule.InsertAsSnippet,
    //           range: {
    //             startLineNumber: position.lineNumber,
    //             endLineNumber: position.lineNumber,
    //             startColumn: word.startColumn,
    //             endColumn: word.endColumn
    //           }
    //         }];
    //         return { suggestions: suggestions };
    //       }
    //     });
    //     monaco.languages.setMonarchTokensProvider('bson', {
    //       tokenizer: {
    //         root: [
    //           [/ObjectId/, "ObjectId"],
    //           [/\".*\"/, "String"],
    //           [/\d/, "Number"]
    //         ]
    //       }
    //     });
    //   }
    // };


    var AppModule = function AppModule() {
      _classCallCheck(this, AppModule);
    };

    AppModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["NgModule"])({
      declarations: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"], _document_document_component__WEBPACK_IMPORTED_MODULE_9__["DocumentComponent"], _common_pipes_pipes__WEBPACK_IMPORTED_MODULE_12__["Type"], _common_pipes_pipes__WEBPACK_IMPORTED_MODULE_12__["IsExpandable"], _common_pipes_pipes__WEBPACK_IMPORTED_MODULE_12__["HasMoreText"], _common_pipes_pipes__WEBPACK_IMPORTED_MODULE_12__["FormatValue"], _common_pipes_file_size_pipe__WEBPACK_IMPORTED_MODULE_13__["FileSizePipe"], _collection_collection_component__WEBPACK_IMPORTED_MODULE_10__["CollectionComponent"]],
      imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_1__["BrowserModule"], _angular_platform_browser_animations__WEBPACK_IMPORTED_MODULE_2__["BrowserAnimationsModule"], _app_routing_module__WEBPACK_IMPORTED_MODULE_5__["AppRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["ReactiveFormsModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HttpClientModule"], ng_zorro_antd__WEBPACK_IMPORTED_MODULE_11__["NgZorroAntdModule"], ngx_monaco_editor__WEBPACK_IMPORTED_MODULE_15__["MonacoEditorModule"].forRoot()],
      providers: [_api_service__WEBPACK_IMPORTED_MODULE_7__["ApiService"], {
        provide: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_11__["NZ_I18N"],
        useValue: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_11__["en_US"]
      }, {
        provide: _angular_common_http__WEBPACK_IMPORTED_MODULE_8__["HTTP_INTERCEPTORS"],
        useClass: _common_interceptors_http_error_interceptor__WEBPACK_IMPORTED_MODULE_14__["HttpErrorInterceptor"],
        multi: true
      }],
      bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_6__["AppComponent"]]
    })], AppModule);
    /***/
  },

  /***/
  "./src/app/collection/collection.component.css":
  /*!*****************************************************!*\
    !*** ./src/app/collection/collection.component.css ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCollectionCollectionComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = ".container {\n  padding: 8px 10px;\n  overflow: auto;\n  height: calc(100vh - 140px);\n  background: #f5f5f5;\n}\n.document {\n  display: grid;\n  grid-template-columns: 9fr 3fr;\n  background-color: #ffffff;\n  padding: 15px 8px;\n  margin-bottom: 8px;\n  position: relative;\n}\n.document-editor {\n  height: calc(100% - 50px) !important;\n}\n.right [nz-button] {\n  margin: 0px 4px !important;\n  height: 25px;\n  width: 25px;\n}\n.document .right [nz-button] {\n  visibility: hidden;\n}\n.document:hover .right [nz-button],\n.document:active .right [nz-button] {\n  visibility: visible;\n  transition-delay: 300ms;\n}\n.query {\n  padding: 0px 10px;\n}\n.query [nz-input] {\n  background: whitesmoke;\n}\n.help {\n  border-bottom: 1px solid #e5e5e5;\n  padding-bottom: 5px;\n}\n.tab-content {\n  grid-template-rows: auto;\n}\n.meta {\n  list-style-type: none;\n  display: inline-flex;\n  padding: 0;\n  margin: 0px;\n}\n.meta li {\n  padding: 0px 15px;\n  vertical-align: middle;\n  line-height: 30px;\n}\n.bar {\n  display: grid;\n  grid-template-columns: 8fr 4fr;\n}\n.btngroup {\n  padding: 0px 10px;\n}\n.loader {\n  top: 35%;\n  left: 40%;\n  position: absolute;\n}\n.footer {\n  position: absolute;\n  bottom: 0px;\n  width: 100%;\n  border-top: 1px solid rgb(232, 232, 232);\n  padding: 10px 16px;\n  text-align: right;\n  left: 0px;\n  background: #fff;\n}\n.pagination {\n  padding: 5px 15px;\n  border-bottom: 3px solid #e5e5e5;\n}\n.left-child,\n.right-child {\n  display: inline-block;\n}\n.right-child {\n  text-align: right;\n  float: right;\n}\n.attributes {\n  margin-top: 10px;\n  height: 225px;\n  overflow: auto;\n}\n.upload {\n  margin-top: 10px;;\n}\n.upload:hover {\n  background-color: rgb(240, 240, 240);\n}\n.copy {\n  position: relative;\n  display: inline-block;\n  height: 0px;\n}\n.copy-as {\n  display: none;\n  position: absolute;\n  border-radius: 5px;\n  padding: 0px;\n  border-top: 2px solid #fff;\n  border-bottom: 2px solid #fff;\n  box-shadow: 0px 5px 8px 0px rgba(0,0,0,0.3);\n  overflow-y: hidden;\n  overflow-x: hidden;\n  background: #fff;\n  z-index: 1000;\n}\n.copy:hover .copy-as {\n  display: block;\n  overflow-y: hidden;\n  overflow-x: hidden;\n}\n.copy-as li {\n  padding: 5px 10px;\n  text-decoration: none;\n  display: block;\n  cursor: pointer;\n}\n.copy-as li:hover {\n  background-color: rgba(24,144,255, 0.2);\n  overflow: hidden;\n}\n\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY29sbGVjdGlvbi9jb2xsZWN0aW9uLmNvbXBvbmVudC5jc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxpQkFBaUI7RUFDakIsY0FBYztFQUNkLDJCQUEyQjtFQUMzQixtQkFBbUI7QUFDckI7QUFDQTtFQUNFLGFBQWE7RUFDYiw4QkFBOEI7RUFDOUIseUJBQXlCO0VBQ3pCLGlCQUFpQjtFQUNqQixrQkFBa0I7RUFDbEIsa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxvQ0FBb0M7QUFDdEM7QUFDQTtFQUNFLDBCQUEwQjtFQUMxQixZQUFZO0VBQ1osV0FBVztBQUNiO0FBQ0E7RUFDRSxrQkFBa0I7QUFDcEI7QUFDQTs7RUFFRSxtQkFBbUI7RUFDbkIsdUJBQXVCO0FBQ3pCO0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLHNCQUFzQjtBQUN4QjtBQUNBO0VBQ0UsZ0NBQWdDO0VBQ2hDLG1CQUFtQjtBQUNyQjtBQUNBO0VBQ0Usd0JBQXdCO0FBQzFCO0FBQ0E7RUFDRSxxQkFBcUI7RUFDckIsb0JBQW9CO0VBQ3BCLFVBQVU7RUFDVixXQUFXO0FBQ2I7QUFDQTtFQUNFLGlCQUFpQjtFQUNqQixzQkFBc0I7RUFDdEIsaUJBQWlCO0FBQ25CO0FBQ0E7RUFDRSxhQUFhO0VBQ2IsOEJBQThCO0FBQ2hDO0FBQ0E7RUFDRSxpQkFBaUI7QUFDbkI7QUFDQTtFQUNFLFFBQVE7RUFDUixTQUFTO0VBQ1Qsa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLFdBQVc7RUFDWCx3Q0FBd0M7RUFDeEMsa0JBQWtCO0VBQ2xCLGlCQUFpQjtFQUNqQixTQUFTO0VBQ1QsZ0JBQWdCO0FBQ2xCO0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsZ0NBQWdDO0FBQ2xDO0FBRUE7O0VBRUUscUJBQXFCO0FBQ3ZCO0FBRUE7RUFDRSxpQkFBaUI7RUFDakIsWUFBWTtBQUNkO0FBRUE7RUFDRSxnQkFBZ0I7RUFDaEIsYUFBYTtFQUNiLGNBQWM7QUFDaEI7QUFFQTtFQUNFLGdCQUFnQjtBQUNsQjtBQUVBO0VBQ0Usb0NBQW9DO0FBQ3RDO0FBRUE7RUFDRSxrQkFBa0I7RUFDbEIscUJBQXFCO0VBQ3JCLFdBQVc7QUFDYjtBQUVBO0VBQ0UsYUFBYTtFQUNiLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLDBCQUEwQjtFQUMxQiw2QkFBNkI7RUFDN0IsMkNBQTJDO0VBQzNDLGtCQUFrQjtFQUNsQixrQkFBa0I7RUFDbEIsZ0JBQWdCO0VBQ2hCLGFBQWE7QUFDZjtBQUVBO0VBQ0UsY0FBYztFQUNkLGtCQUFrQjtFQUNsQixrQkFBa0I7QUFDcEI7QUFFQTtFQUNFLGlCQUFpQjtFQUNqQixxQkFBcUI7RUFDckIsY0FBYztFQUNkLGVBQWU7QUFDakI7QUFFQTtFQUNFLHVDQUF1QztFQUN2QyxnQkFBZ0I7QUFDbEIiLCJmaWxlIjoic3JjL2FwcC9jb2xsZWN0aW9uL2NvbGxlY3Rpb24uY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbIi5jb250YWluZXIge1xuICBwYWRkaW5nOiA4cHggMTBweDtcbiAgb3ZlcmZsb3c6IGF1dG87XG4gIGhlaWdodDogY2FsYygxMDB2aCAtIDE0MHB4KTtcbiAgYmFja2dyb3VuZDogI2Y1ZjVmNTtcbn1cbi5kb2N1bWVudCB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogOWZyIDNmcjtcbiAgYmFja2dyb3VuZC1jb2xvcjogI2ZmZmZmZjtcbiAgcGFkZGluZzogMTVweCA4cHg7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuLmRvY3VtZW50LWVkaXRvciB7XG4gIGhlaWdodDogY2FsYygxMDAlIC0gNTBweCkgIWltcG9ydGFudDtcbn1cbi5yaWdodCBbbnotYnV0dG9uXSB7XG4gIG1hcmdpbjogMHB4IDRweCAhaW1wb3J0YW50O1xuICBoZWlnaHQ6IDI1cHg7XG4gIHdpZHRoOiAyNXB4O1xufVxuLmRvY3VtZW50IC5yaWdodCBbbnotYnV0dG9uXSB7XG4gIHZpc2liaWxpdHk6IGhpZGRlbjtcbn1cbi5kb2N1bWVudDpob3ZlciAucmlnaHQgW256LWJ1dHRvbl0sXG4uZG9jdW1lbnQ6YWN0aXZlIC5yaWdodCBbbnotYnV0dG9uXSB7XG4gIHZpc2liaWxpdHk6IHZpc2libGU7XG4gIHRyYW5zaXRpb24tZGVsYXk6IDMwMG1zO1xufVxuLnF1ZXJ5IHtcbiAgcGFkZGluZzogMHB4IDEwcHg7XG59XG4ucXVlcnkgW256LWlucHV0XSB7XG4gIGJhY2tncm91bmQ6IHdoaXRlc21va2U7XG59XG4uaGVscCB7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCAjZTVlNWU1O1xuICBwYWRkaW5nLWJvdHRvbTogNXB4O1xufVxuLnRhYi1jb250ZW50IHtcbiAgZ3JpZC10ZW1wbGF0ZS1yb3dzOiBhdXRvO1xufVxuLm1ldGEge1xuICBsaXN0LXN0eWxlLXR5cGU6IG5vbmU7XG4gIGRpc3BsYXk6IGlubGluZS1mbGV4O1xuICBwYWRkaW5nOiAwO1xuICBtYXJnaW46IDBweDtcbn1cbi5tZXRhIGxpIHtcbiAgcGFkZGluZzogMHB4IDE1cHg7XG4gIHZlcnRpY2FsLWFsaWduOiBtaWRkbGU7XG4gIGxpbmUtaGVpZ2h0OiAzMHB4O1xufVxuLmJhciB7XG4gIGRpc3BsYXk6IGdyaWQ7XG4gIGdyaWQtdGVtcGxhdGUtY29sdW1uczogOGZyIDRmcjtcbn1cbi5idG5ncm91cCB7XG4gIHBhZGRpbmc6IDBweCAxMHB4O1xufVxuLmxvYWRlciB7XG4gIHRvcDogMzUlO1xuICBsZWZ0OiA0MCU7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbn1cbi5mb290ZXIge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogMHB4O1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLXRvcDogMXB4IHNvbGlkIHJnYigyMzIsIDIzMiwgMjMyKTtcbiAgcGFkZGluZzogMTBweCAxNnB4O1xuICB0ZXh0LWFsaWduOiByaWdodDtcbiAgbGVmdDogMHB4O1xuICBiYWNrZ3JvdW5kOiAjZmZmO1xufVxuXG4ucGFnaW5hdGlvbiB7XG4gIHBhZGRpbmc6IDVweCAxNXB4O1xuICBib3JkZXItYm90dG9tOiAzcHggc29saWQgI2U1ZTVlNTtcbn1cblxuLmxlZnQtY2hpbGQsXG4ucmlnaHQtY2hpbGQge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG59XG5cbi5yaWdodC1jaGlsZCB7XG4gIHRleHQtYWxpZ246IHJpZ2h0O1xuICBmbG9hdDogcmlnaHQ7XG59XG5cbi5hdHRyaWJ1dGVzIHtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgaGVpZ2h0OiAyMjVweDtcbiAgb3ZlcmZsb3c6IGF1dG87XG59XG5cbi51cGxvYWQge1xuICBtYXJnaW4tdG9wOiAxMHB4Oztcbn1cblxuLnVwbG9hZDpob3ZlciB7XG4gIGJhY2tncm91bmQtY29sb3I6IHJnYigyNDAsIDI0MCwgMjQwKTtcbn1cblxuLmNvcHkge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgaGVpZ2h0OiAwcHg7XG59XG5cbi5jb3B5LWFzIHtcbiAgZGlzcGxheTogbm9uZTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIHBhZGRpbmc6IDBweDtcbiAgYm9yZGVyLXRvcDogMnB4IHNvbGlkICNmZmY7XG4gIGJvcmRlci1ib3R0b206IDJweCBzb2xpZCAjZmZmO1xuICBib3gtc2hhZG93OiAwcHggNXB4IDhweCAwcHggcmdiYSgwLDAsMCwwLjMpO1xuICBvdmVyZmxvdy15OiBoaWRkZW47XG4gIG92ZXJmbG93LXg6IGhpZGRlbjtcbiAgYmFja2dyb3VuZDogI2ZmZjtcbiAgei1pbmRleDogMTAwMDtcbn1cblxuLmNvcHk6aG92ZXIgLmNvcHktYXMge1xuICBkaXNwbGF5OiBibG9jaztcbiAgb3ZlcmZsb3cteTogaGlkZGVuO1xuICBvdmVyZmxvdy14OiBoaWRkZW47XG59XG5cbi5jb3B5LWFzIGxpIHtcbiAgcGFkZGluZzogNXB4IDEwcHg7XG4gIHRleHQtZGVjb3JhdGlvbjogbm9uZTtcbiAgZGlzcGxheTogYmxvY2s7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cblxuLmNvcHktYXMgbGk6aG92ZXIge1xuICBiYWNrZ3JvdW5kLWNvbG9yOiByZ2JhKDI0LDE0NCwyNTUsIDAuMik7XG4gIG92ZXJmbG93OiBoaWRkZW47XG59XG4iXX0= */";
    /***/
  },

  /***/
  "./src/app/collection/collection.component.ts":
  /*!****************************************************!*\
    !*** ./src/app/collection/collection.component.ts ***!
    \****************************************************/

  /*! exports provided: CollectionComponent */

  /***/
  function srcAppCollectionCollectionComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CollectionComponent", function () {
      return CollectionComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _api_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../api.service */
    "./src/app/api.service.ts");
    /* harmony import */


    var ng_zorro_antd_message__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ng-zorro-antd/message */
    "./node_modules/ng-zorro-antd/fesm2015/ng-zorro-antd-message.js");
    /* harmony import */


    var bson__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! bson */
    "./node_modules/bson/dist/bson.browser.esm.js");
    /* harmony import */


    var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ng-zorro-antd */
    "./node_modules/ng-zorro-antd/fesm2015/ng-zorro-antd.js");
    /* harmony import */


    var lodash__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! lodash */
    "./node_modules/lodash/lodash.js");
    /* harmony import */


    var lodash__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_6__);

    var Papa = __webpack_require__(
    /*! papaparse */
    "./node_modules/papaparse/papaparse.min.js");

    var CollectionComponent = /*#__PURE__*/function () {
      function CollectionComponent(API, message, notification) {
        var _this7 = this;

        _classCallCheck(this, CollectionComponent);

        this.API = API;
        this.message = message;
        this.notification = notification;
        this.filter = '';
        this.loading = false;
        this.pageIndex = 1;
        this.showEditor = false;
        this.documentEditorMode = 'create';
        this.searchMode = 'simple';
        this.searchObj = {
          key: '',
          value: '',
          type: 'String'
        };
        this.showAdvancedSearchForm = false;
        this.error = {
          status: false,
          desc: ''
        };
        this.editorOptions = {
          theme: 'vs',
          language: 'json',
          suggest: {
            showIcons: false
          },
          contextmenu: false,
          codeLens: false,
          renderLineHighlight: 'none'
        };
        this.code = '{}';
        this.importButton = false;
        this.file = '';
        this.importing = false;
        this.attributes = [];
        this.isImportVisible = false;
        this.ignore = false;
        this.isExportVisible = false;
        this.exportButton = true;
        this.exporting = false;
        this.exportAs = 'json';
        this.count = 0;

        this.beforeUpload = function (file) {
          _this7.importError = '';
          _this7.attributes = [];
          _this7.rowData = [];
          _this7.importButton = false;

          if (file.type !== 'text/csv' && file.type !== 'application/json') {
            _this7.message.error('You can only upload either JSON or CSV files!');

            _this7.importing = false;
            _this7.file = '';
            return false;
          }

          _this7.file = file.name;

          try {
            if (file.type === 'text/csv') {
              Papa.parse(file, {
                header: true,
                skipEmptyLines: true,
                complete: function complete(result) {
                  if (!result.errors[0]) {
                    var keys = lodash__WEBPACK_IMPORTED_MODULE_6__["take"](lodash__WEBPACK_IMPORTED_MODULE_6__["keys"](result.data[0]), 1500);
                    _this7.attributes = lodash__WEBPACK_IMPORTED_MODULE_6__["map"](keys, function (key) {
                      return {
                        include: true,
                        label: key,
                        type: 'String'
                      };
                    });
                    _this7.rowData = result.data;
                    _this7.importButton = true;
                  } else {
                    _this7.importError = result.errors[0].message;
                    _this7.rowData = [];
                    _this7.importButton = false;
                  }
                }
              });
            } else {
              var reader = new FileReader();
              reader.readAsText(file);

              reader.onload = function (e) {
                _this7.rowData = reader.result;
                _this7.importButton = true;
              };

              reader.onerror = function (e) {
                _this7.importError = reader.error;
                _this7.rowData = [];
                _this7.importButton = false;
              };
            }
          } catch (err) {
            _this7.importError = err.message;
            _this7.rowData = [];
            _this7.importButton = false;
          }

          return false;
        };
      }

      _createClass(CollectionComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.query();
        }
      }, {
        key: "query",
        value: function query() {
          var _this8 = this;

          // console.log(this.code, '#####');
          this.loading = true;
          this.API.filterDocumentsByQuery(this.database, this.collection, this.ejsonFilter || bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize({}), this.pageIndex).subscribe(function (documents) {
            _this8.data = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].deserialize(documents);
            _this8.count = _this8.data.count;
            if (_this8.searchMode === 'advanced') _this8.closeAdvancedSearchForm();
          }).add(function () {
            _this8.loading = false;
          });
        }
      }, {
        key: "getQuery",
        value: function getQuery() {
          if (this.searchMode === 'simple') {
            if (!this.searchObj.key) return '{}';
            var key = this.searchObj.key;
            var value = this.searchObj.value;
            if (this.searchObj.type === 'ObjectId' && bson__WEBPACK_IMPORTED_MODULE_4__["ObjectId"].isValid(value)) value = {
              $oid: value
            };
            if (this.searchObj.type === 'Date') value = {
              $date: value
            };
            if (this.searchObj.type === 'Number') value = {
              $numberInt: value
            };

            if (this.searchObj.type === 'Boolean') {
              if (value === 'true') value = true;else {
                value = false;
                this.searchObj.value = 'false';
              }
            }

            return JSON.stringify(_defineProperty({}, key, value));
          } else return this.filter;
        }
      }, {
        key: "uiQuery",
        value: function uiQuery() {
          this.pageIndex = 1;
          this.filter = this.getQuery();

          try {
            this.ejsonFilter = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize(JSON.parse(this.filter));
          } catch (err) {
            alert('Invalid query');
          }

          this.query();
        }
      }, {
        key: "clearFilter",
        value: function clearFilter() {
          this.filter = '';
          this.ejsonFilter = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize({});
          this.searchObj = {
            key: '',
            value: '',
            type: 'String'
          };
          this.query();
        }
      }, {
        key: "deleteDocument",
        value: function deleteDocument(doc) {
          var _this9 = this;

          this.API.deleteDocumentById(this.database, this.collection, bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize(lodash__WEBPACK_IMPORTED_MODULE_6__["pick"](doc, '_id'))).subscribe(function () {
            try {
              _this9.API.getDocumentCount(_this9.database, _this9.collection, _this9.filter ? JSON.parse(_this9.filter) : {}).subscribe(function (res) {
                _this9.message.info('Deleted!');

                _this9.data = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].deserialize(res);
                if (_this9.pageIndex * 10 >= _this9.data.count) _this9.pageIndex = Math.ceil(_this9.data.count / 10);
                if (_this9.data.count === 0) _this9.pageIndex = 1;

                _this9.query();
              });
            } catch (err) {
              alert('Invalid JSON query!!');
              _this9.loading = false;
            }
          });
        }
      }, {
        key: "updateDocument",
        value: function updateDocument() {
          var _this10 = this;

          try {
            this.error.status = false;
            this.error.desc = '';
            var originalDocument = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize(JSON.parse(this.documentBeingEdited)); // const method = this.documentEditorMode === 'create' ? this.API.createDocument : this.API.updateDocument

            this.API.createDocuments(this.database, this.collection, originalDocument).subscribe(function (response) {
              try {
                if (!response['nUpserted']) {
                  _this10.closeEditor();

                  _this10.message.success('Success!');

                  _this10.query();

                  return;
                }

                _this10.API.getDocumentCount(_this10.database, _this10.collection, _this10.filter ? JSON.parse(_this10.filter) : {}).subscribe(function (res) {
                  _this10.closeEditor();

                  _this10.message.success('Success!');

                  _this10.data = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].deserialize(res);
                  _this10.pageIndex = Math.ceil(_this10.data.count / 10);
                  if (_this10.data.count === 0) _this10.pageIndex = 1;

                  _this10.query();
                });
              } catch (err) {
                alert('Invalid JSON query!!');
                _this10.loading = false;
              }
            });
          } catch (err) {
            this.error.status = true;
            this.error.desc = err;
          }
        }
      }, {
        key: "openEditor",
        value: function openEditor(doc, mode) {
          this.documentEditorMode = mode || 'create';
          this.showEditor = true;
          this.documentBeingEdited = JSON.stringify(bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize(doc), undefined, 4);
        }
      }, {
        key: "closeEditor",
        value: function closeEditor() {
          this.showEditor = false;
          this.documentBeingEdited = '';
        }
      }, {
        key: "openAdvancedSearchForm",
        value: function openAdvancedSearchForm() {
          this.showAdvancedSearchForm = true;
        }
      }, {
        key: "closeAdvancedSearchForm",
        value: function closeAdvancedSearchForm() {
          this.showAdvancedSearchForm = false;
        }
      }, {
        key: "copyToClipboard",
        value: function copyToClipboard(text, type) {
          text = JSON.stringify(type === 'BSON' ? bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize(text) : text);
          var txtArea = document.createElement('textarea');
          txtArea.style.position = 'fixed';
          txtArea.style.top = '0';
          txtArea.style.left = '0';
          txtArea.style.opacity = '0';
          txtArea.value = text;
          document.body.appendChild(txtArea);
          txtArea.select();

          try {
            var result = document.execCommand('copy');

            if (result) {
              this.message.success('Copied!');
            }
          } catch (err) {}

          document.body.removeChild(txtArea);
        }
      }, {
        key: "showImportModal",
        value: function showImportModal() {
          this.isImportVisible = true;
          this.file = '';
          this.rowData = [];
          this.importError = '';
          this.importButton = false;
          this.importing = false;
        }
      }, {
        key: "importRecords",
        value: function importRecords() {
          var _this11 = this;

          var records = [];

          try {
            if (this.attributes[0]) {
              this.importError = '';
              this.importing = true;
              this.importButton = false;

              var _iterator = _createForOfIteratorHelper(this.rowData),
                  _step;

              try {
                for (_iterator.s(); !(_step = _iterator.n()).done;) {
                  var row = _step.value;
                  var record = {};

                  var _iterator2 = _createForOfIteratorHelper(this.attributes),
                      _step2;

                  try {
                    for (_iterator2.s(); !(_step2 = _iterator2.n()).done;) {
                      var attribute = _step2.value;

                      if (attribute.include) {
                        if (lodash__WEBPACK_IMPORTED_MODULE_6__["get"](row, attribute.label)) {
                          switch (attribute.type) {
                            case 'ObjectId':
                              row[attribute.label] = new bson__WEBPACK_IMPORTED_MODULE_4__["ObjectId"](row[attribute.label]);
                              break;

                            case 'Boolean':
                              row[attribute.label] = Boolean(row[attribute.label]);
                              break;

                            case 'Date':
                              row[attribute.label] = {
                                $date: row[attribute.label]
                              };
                              break;

                            case 'Number':
                              row[attribute.label] = {
                                $numberInt: row[attribute.label]
                              };
                              break;

                            default:
                              row[attribute.label] = String(row[attribute.label]);
                              break;
                          }

                          lodash__WEBPACK_IMPORTED_MODULE_6__["set"](record, attribute.label, row[attribute.label]);
                        }
                      }
                    }
                  } catch (err) {
                    _iterator2.e(err);
                  } finally {
                    _iterator2.f();
                  }

                  if (this.importing) {
                    records.push(record);
                    this.importError = '';
                  } else {
                    records = [];
                    break;
                  }
                }
              } catch (err) {
                _iterator.e(err);
              } finally {
                _iterator.f();
              }
            } else {
              records = this.rowData;
              this.importError = '';
              this.importing = true;
              this.importButton = false;
            }

            if (!this.importError) {
              var originalDocument = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize(typeof records === 'string' ? JSON.parse(records) : records);
              this.API.createDocuments(this.database, this.collection, originalDocument).subscribe(function (response) {
                _this11.importing = false;
                _this11.importButton = false;

                if (!response['nUpserted']) {
                  _this11.message.success('Success!');

                  _this11.query();

                  _this11.closeImportModal();

                  return;
                }

                _this11.API.getDocumentCount(_this11.database, _this11.collection, _this11.filter ? JSON.parse(_this11.filter) : {}).subscribe(function (res) {
                  _this11.message.success('Success!');

                  _this11.closeImportModal();

                  _this11.data = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].deserialize(res);
                  _this11.pageIndex = Math.ceil(_this11.data.count / 10);

                  _this11.query();
                }, function (error) {
                  _this11.importError = error;
                  _this11.importButton = true;
                  _this11.importing = false;
                });
              }, function (error) {
                _this11.importError = error;
                _this11.importButton = true;
                _this11.importing = false;
              });
            }
          } catch (err) {
            this.importError = err.message;
            this.importButton = true;
            this.importing = false;
          }
        }
      }, {
        key: "closeImportModal",
        value: function closeImportModal() {
          this.isImportVisible = false;
          this.importing = false;
        }
      }, {
        key: "getExportAttributes",
        value: function getExportAttributes() {
          var _this12 = this;

          this.attributes = [];
          this.API.aggregate(this.database, this.collection, [{
            $match: this.ejsonFilter || bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize({})
          }, {
            $project: {
              arrayofkeyvalue: {
                $objectToArray: '$$ROOT'
              }
            }
          }, {
            $unwind: '$arrayofkeyvalue'
          }, {
            $group: {
              _id: null,
              allkeys: {
                $addToSet: '$arrayofkeyvalue.k'
              }
            }
          }]).subscribe(function (documents) {
            var keys = new Set(documents[0].allkeys.sort());

            var _iterator3 = _createForOfIteratorHelper(keys),
                _step3;

            try {
              for (_iterator3.s(); !(_step3 = _iterator3.n()).done;) {
                var key = _step3.value;

                _this12.attributes.push({
                  include: true,
                  label: key
                });
              }
            } catch (err) {
              _iterator3.e(err);
            } finally {
              _iterator3.f();
            }
          });
        }
      }, {
        key: "showExportModal",
        value: function showExportModal() {
          this.isExportVisible = true;
          this.exporting = false;
          this.exportAs = 'json';
          this.exportButton = true;
          this.getExportAttributes();
        }
      }, {
        key: "closeExportModal",
        value: function closeExportModal() {
          this.isExportVisible = false;
          this.exporting = false;
          this.attributes = [];
          this.exportAs = 'json';
          this.exportButton = true;
        }
      }, {
        key: "exportCollection",
        value: function exportCollection() {
          var _this13 = this;

          this.exporting = true;
          this.exportButton = false;
          var excludedAttributes = [],
              includedAttributes = [];

          var _iterator4 = _createForOfIteratorHelper(this.attributes),
              _step4;

          try {
            for (_iterator4.s(); !(_step4 = _iterator4.n()).done;) {
              var attribute = _step4.value;
              if (!attribute.include) excludedAttributes.push(attribute.label);else includedAttributes.push(attribute.label);
            }
          } catch (err) {
            _iterator4.e(err);
          } finally {
            _iterator4.f();
          }

          var query = [{
            $match: this.ejsonFilter || bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].serialize({})
          }, {
            $unset: excludedAttributes
          }];
          if (!excludedAttributes[0] || this.exportAs !== 'csv') query.pop();
          this.API.aggregate(this.database, this.collection, query).subscribe(function (documents) {
            documents = bson__WEBPACK_IMPORTED_MODULE_4__["EJSON"].parse(JSON.stringify(documents));

            if (_this13.exportAs === 'csv') {
              var _iterator5 = _createForOfIteratorHelper(documents),
                  _step5;

              try {
                for (_iterator5.s(); !(_step5 = _iterator5.n()).done;) {
                  var row = _step5.value;

                  var _iterator6 = _createForOfIteratorHelper(includedAttributes),
                      _step6;

                  try {
                    for (_iterator6.s(); !(_step6 = _iterator6.n()).done;) {
                      var attribute = _step6.value;
                      var rowLabel = lodash__WEBPACK_IMPORTED_MODULE_6__["get"](row, attribute);
                      if (typeof rowLabel === 'object') lodash__WEBPACK_IMPORTED_MODULE_6__["set"](row, attribute, JSON.stringify(rowLabel));
                    }
                  } catch (err) {
                    _iterator6.e(err);
                  } finally {
                    _iterator6.f();
                  }
                }
              } catch (err) {
                _iterator5.e(err);
              } finally {
                _iterator5.f();
              }

              if (includedAttributes[0]) documents = Papa.unparse(documents, {
                columns: includedAttributes
              });else documents = Papa.unparse(documents);
            } else documents = JSON.stringify(documents, null, 2);

            var blob = new Blob([documents], {
              type: 'application/octet-stream'
            });
            var url = window.URL.createObjectURL(blob);
            var anchor = document.createElement('a');
            anchor.download = "".concat(_this13.collection, ".").concat(_this13.exportAs);
            anchor.href = url;
            anchor.click();
            _this13.exportButton = true;
            _this13.exporting = false;
          });
        }
      }]);

      return CollectionComponent;
    }();

    CollectionComponent.ctorParameters = function () {
      return [{
        type: _api_service__WEBPACK_IMPORTED_MODULE_2__["ApiService"]
      }, {
        type: ng_zorro_antd_message__WEBPACK_IMPORTED_MODULE_3__["NzMessageService"]
      }, {
        type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_5__["NzNotificationService"]
      }];
    };

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CollectionComponent.prototype, "database", void 0);
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], CollectionComponent.prototype, "collection", void 0);
    CollectionComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-collection',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./collection.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/collection/collection.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./collection.component.css */
      "./src/app/collection/collection.component.css"))["default"]]
    })], CollectionComponent);
    /***/
  },

  /***/
  "./src/app/common/interceptors/http-error.interceptor.ts":
  /*!***************************************************************!*\
    !*** ./src/app/common/interceptors/http-error.interceptor.ts ***!
    \***************************************************************/

  /*! exports provided: HttpErrorInterceptor */

  /***/
  function srcAppCommonInterceptorsHttpErrorInterceptorTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HttpErrorInterceptor", function () {
      return HttpErrorInterceptor;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ng-zorro-antd */
    "./node_modules/ng-zorro-antd/fesm2015/ng-zorro-antd.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var HttpErrorInterceptor = /*#__PURE__*/function () {
      function HttpErrorInterceptor(notification) {
        _classCallCheck(this, HttpErrorInterceptor);

        this.notification = notification;
      }

      _createClass(HttpErrorInterceptor, [{
        key: "intercept",
        value: function intercept(request, next) {
          var _this14 = this;

          return next.handle(request).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["retry"])(1), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["catchError"])(function (error) {
            var name = 'Error';
            var errorMessage = '';

            if (error.error instanceof ErrorEvent) {
              // client-side error
              errorMessage = error.error.message;
            } else {
              // server-side error
              name = error.error.name || error.name;
              errorMessage = error.error.errmsg || error.error || error.message;
            }

            _this14.notification.create('error', name, errorMessage);

            return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["throwError"])(errorMessage);
          }));
        }
      }]);

      return HttpErrorInterceptor;
    }();

    HttpErrorInterceptor.ctorParameters = function () {
      return [{
        type: ng_zorro_antd__WEBPACK_IMPORTED_MODULE_3__["NzNotificationService"]
      }];
    };

    HttpErrorInterceptor = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_4__["Injectable"])()], HttpErrorInterceptor);
    /***/
  },

  /***/
  "./src/app/common/pipes/file-size.pipe.ts":
  /*!************************************************!*\
    !*** ./src/app/common/pipes/file-size.pipe.ts ***!
    \************************************************/

  /*! exports provided: FileSizePipe */

  /***/
  function srcAppCommonPipesFileSizePipeTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FileSizePipe", function () {
      return FileSizePipe;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /**
     * @license
     * Copyright (c) 2019 Jonathan Catmull.
     *
     * Permission is hereby granted, free of charge, to any person obtaining a copy
     * of this software and associated documentation files (the "Software"), to deal
     * in the Software without restriction, including without limitation the rights
     * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
     * copies of the Software, and to permit persons to whom the Software is
     * furnished to do so, subject to the following conditions:
     *
     * The above copyright notice and this permission notice shall be included in all
     * copies or substantial portions of the Software.
     *
     * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
     * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
     * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
     * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
     * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
     * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
     * SOFTWARE.
     */


    var defaultPrecisionMap = {
      bytes: 0,
      KB: 0,
      MB: 1,
      GB: 1,
      TB: 2,
      PB: 2
    };
    /*
     * Convert bytes into largest possible unit.
     * Takes an precision argument that can be a number or a map for each unit.
     * Usage:
     *   bytes | fileSize:precision
     * @example
     * // returns 1 KB
     * {{ 1500 | fileSize }}
     * @example
     * // returns 2.1 GB
     * {{ 2100000000 | fileSize }}
     * @example
     * // returns 1.46 KB
     * {{ 1500 | fileSize:2 }}
     */

    var FileSizePipe = /*#__PURE__*/function () {
      /*
       * Convert bytes into largest possible unit.
       * Takes an precision argument that can be a number or a map for each unit.
       * Usage:
       *   bytes | fileSize:precision
       * @example
       * // returns 1 KB
       * {{ 1500 | fileSize }}
       * @example
       * // returns 2.1 GB
       * {{ 2100000000 | fileSize }}
       * @example
       * // returns 1.46 KB
       * {{ 1500 | fileSize:2 }}
       */
      function FileSizePipe() {
        _classCallCheck(this, FileSizePipe);

        this.units = ['bytes', 'KB', 'MB', 'GB', 'TB', 'PB'];
      }

      _createClass(FileSizePipe, [{
        key: "transform",
        value: function transform() {
          var bytes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
          var precision = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : defaultPrecisionMap;
          if (isNaN(parseFloat(String(bytes))) || !isFinite(bytes)) return '?';
          var unitIndex = 0;

          while (bytes >= 1024) {
            bytes /= 1024;
            unitIndex++;
          }

          var unit = this.units[unitIndex];

          if (typeof precision === 'number') {
            return "".concat(bytes.toFixed(+precision), " ").concat(unit);
          }

          return "".concat(bytes.toFixed(precision[unit]), " ").concat(unit);
        }
      }]);

      return FileSizePipe;
    }();

    FileSizePipe = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'fileSize'
    })], FileSizePipe);
    /***/
  },

  /***/
  "./src/app/common/pipes/pipes.ts":
  /*!***************************************!*\
    !*** ./src/app/common/pipes/pipes.ts ***!
    \***************************************/

  /*! exports provided: Type, HasMoreText, IsExpandable, FormatValue */

  /***/
  function srcAppCommonPipesPipesTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Type", function () {
      return Type;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HasMoreText", function () {
      return HasMoreText;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "IsExpandable", function () {
      return IsExpandable;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "FormatValue", function () {
      return FormatValue;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var Type = /*#__PURE__*/function () {
      function Type() {
        _classCallCheck(this, Type);
      }

      _createClass(Type, [{
        key: "transform",
        value: function transform(value) {
          if (value === null) return 'null';
          if (value === undefined) return 'undefined';
          return value._bsontype || value.constructor.name;
        }
      }]);

      return Type;
    }();

    Type = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'type'
    })], Type);

    var HasMoreText = /*#__PURE__*/function () {
      function HasMoreText() {
        _classCallCheck(this, HasMoreText);
      }

      _createClass(HasMoreText, [{
        key: "transform",
        value: function transform(value) {
          return value.length > 79;
        }
      }]);

      return HasMoreText;
    }();

    HasMoreText = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'hasMoreText'
    })], HasMoreText);

    var IsExpandable = /*#__PURE__*/function () {
      function IsExpandable() {
        _classCallCheck(this, IsExpandable);
      }

      _createClass(IsExpandable, [{
        key: "transform",
        value: function transform(value) {
          var type = new Type();
          var bsonType = type.transform(value);
          if (bsonType !== 'Object' && bsonType !== 'Array') return false;
          if (bsonType === 'Object') value = Object.keys(value);
          return value.length ? true : false;
        }
      }]);

      return IsExpandable;
    }();

    IsExpandable = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'isExpandable'
    })], IsExpandable);

    var FormatValue = /*#__PURE__*/function () {
      function FormatValue() {
        _classCallCheck(this, FormatValue);
      }

      _createClass(FormatValue, [{
        key: "transform",
        value: function transform(value) {
          var type = new Type();
          var isExpandable = new IsExpandable();
          var hasMoreText = new HasMoreText();
          var bsonType = type.transform(value);
          var template;

          switch (bsonType) {
            case 'null':
              template = 'null';
              break;

            case 'undefined':
              template = 'undefined';
              break;

            case 'String':
              template = "\"".concat(hasMoreText.transform(value) ? "".concat(value.substring(0, 79), "...") : value, "\"");
              break;

            case 'ObjectID':
              template = "ObjectId(\"".concat(value, "\")");
              break;

            case 'Date':
              template = value.toJSON();
              break;

            case 'MinKey':
              template = 'MinKey()';
              break;

            case 'MaxKey':
              template = 'MaxKey()';
              break;

            case 'Binary':
              template = "Binary('".concat(value.toJSON(), "', ").concat(value.sub_type, ")");
              break;

            case 'Object':
              template = "".concat(isExpandable.transform(value) ? 'Object' : '{}');
              break;

            case 'Array':
              template = "".concat(isExpandable.transform(value) ? 'Array[' + value.length + ']' : '[]');
              break;

            default:
              template = value;
              break;
          }

          return template;
        }
      }]);

      return FormatValue;
    }();

    FormatValue = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Pipe"])({
      name: 'formatValue'
    })], FormatValue);
    /***/
  },

  /***/
  "./src/app/document/document.component.css":
  /*!*************************************************!*\
    !*** ./src/app/document/document.component.css ***!
    \*************************************************/

  /*! exports provided: default */

  /***/
  function srcAppDocumentDocumentComponentCss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ul {\n  list-style-type: none;\n  margin-bottom: 0px;\n  font-family: monospace;\n}\nul li {\n  position: relative;\n  line-height: initial;\n}\nli ul {\n  display: none;\n}\n.open {\n  display: block !important;\n}\n.String .value{\n  color: #2a9ead !important;\n  height: 1rem;\n  overflow: hidden;\n}\n.Number .value{\n  color: #4b714d !important;\n}\n.Boolean .value {\n  color: firebrick !important;\n}\n.Date .value {\n  color: #e91e63 !important;\n}\n.null .value {\n  color: #3f51b5 !important;\n}\n.ObjectID .value {\n  color: #f7754c !important;\n}\n.RegExp .value {\n  color: #999 !important;\n}\n.Timestamp .value {\n  color: #333 !important;\n}\n.Code .value {\n  color: #0053a6 !important;\n}\n.meta-data {\n  /* font-style: italic; */\n  color: #999 !important;\n  font-size: x-small !important;\n  font-weight: 100;\n}\n.key {\n  font-weight: 600;\n  color: #444;\n  font-size: smaller;\n}\n.value {\n  font-weight: 600;\n  font-size: smaller;\n  color: #999;\n  word-break: break-all;\n}\n.fieldset {\n  line-height: 18px;\n  word-wrap: break-word;\n}\n.collapsed::before {\n  /* content: '\\25B7'; */\n  /* content: '+'; */\n  content: '\\276F';\n}\n.expanded::before {\n  /* content: '\\25E2'; */\n  /* content: '-'; */\n  content: '\\276F';\n  display: inline-block;\n  transform: rotate(90deg);\n}\n.toggle {\n  position: absolute;\n  left: -16px;\n  cursor: pointer;\n  color: #b1a1a1 !important;\n  width: 12px;\n  line-height: 12px;\n  top: 4px;\n  text-align: center;\n  cursor: pointer;\n  font-size: x-small;\n}\n.fieldset {\n  display: inline-flex;\n}\n.full-text {\n  height: auto !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZG9jdW1lbnQvZG9jdW1lbnQuY29tcG9uZW50LmNzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFxQjtFQUNyQixrQkFBa0I7RUFDbEIsc0JBQXNCO0FBQ3hCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsb0JBQW9CO0FBQ3RCO0FBQ0E7RUFDRSxhQUFhO0FBQ2Y7QUFDQTtFQUNFLHlCQUF5QjtBQUMzQjtBQUNBO0VBQ0UseUJBQXlCO0VBQ3pCLFlBQVk7RUFDWixnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLHlCQUF5QjtBQUMzQjtBQUNBO0VBQ0UsMkJBQTJCO0FBQzdCO0FBQ0E7RUFDRSx5QkFBeUI7QUFDM0I7QUFDQTtFQUNFLHlCQUF5QjtBQUMzQjtBQUNBO0VBQ0UseUJBQXlCO0FBQzNCO0FBQ0E7RUFDRSxzQkFBc0I7QUFDeEI7QUFDQTtFQUNFLHNCQUFzQjtBQUN4QjtBQUNBO0VBQ0UseUJBQXlCO0FBQzNCO0FBQ0E7RUFDRSx3QkFBd0I7RUFDeEIsc0JBQXNCO0VBQ3RCLDZCQUE2QjtFQUM3QixnQkFBZ0I7QUFDbEI7QUFDQTtFQUNFLGdCQUFnQjtFQUNoQixXQUFXO0VBQ1gsa0JBQWtCO0FBQ3BCO0FBQ0E7RUFDRSxnQkFBZ0I7RUFDaEIsa0JBQWtCO0VBQ2xCLFdBQVc7RUFDWCxxQkFBcUI7QUFDdkI7QUFDQTtFQUNFLGlCQUFpQjtFQUNqQixxQkFBcUI7QUFDdkI7QUFDQTtFQUNFLHNCQUFzQjtFQUN0QixrQkFBa0I7RUFDbEIsZ0JBQWdCO0FBQ2xCO0FBQ0E7RUFDRSxzQkFBc0I7RUFDdEIsa0JBQWtCO0VBQ2xCLGdCQUFnQjtFQUNoQixxQkFBcUI7RUFJckIsd0JBQXdCO0FBQzFCO0FBQ0E7RUFDRSxrQkFBa0I7RUFDbEIsV0FBVztFQUNYLGVBQWU7RUFDZix5QkFBeUI7RUFDekIsV0FBVztFQUNYLGlCQUFpQjtFQUNqQixRQUFRO0VBQ1Isa0JBQWtCO0VBQ2xCLGVBQWU7RUFDZixrQkFBa0I7QUFDcEI7QUFFQTtFQUNFLG9CQUFvQjtBQUN0QjtBQUVBO0VBQ0UsdUJBQXVCO0FBQ3pCIiwiZmlsZSI6InNyYy9hcHAvZG9jdW1lbnQvZG9jdW1lbnQuY29tcG9uZW50LmNzcyIsInNvdXJjZXNDb250ZW50IjpbInVsIHtcbiAgbGlzdC1zdHlsZS10eXBlOiBub25lO1xuICBtYXJnaW4tYm90dG9tOiAwcHg7XG4gIGZvbnQtZmFtaWx5OiBtb25vc3BhY2U7XG59XG51bCBsaSB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbGluZS1oZWlnaHQ6IGluaXRpYWw7XG59XG5saSB1bCB7XG4gIGRpc3BsYXk6IG5vbmU7XG59XG4ub3BlbiB7XG4gIGRpc3BsYXk6IGJsb2NrICFpbXBvcnRhbnQ7XG59XG4uU3RyaW5nIC52YWx1ZXtcbiAgY29sb3I6ICMyYTllYWQgIWltcG9ydGFudDtcbiAgaGVpZ2h0OiAxcmVtO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLk51bWJlciAudmFsdWV7XG4gIGNvbG9yOiAjNGI3MTRkICFpbXBvcnRhbnQ7XG59XG4uQm9vbGVhbiAudmFsdWUge1xuICBjb2xvcjogZmlyZWJyaWNrICFpbXBvcnRhbnQ7XG59XG4uRGF0ZSAudmFsdWUge1xuICBjb2xvcjogI2U5MWU2MyAhaW1wb3J0YW50O1xufVxuLm51bGwgLnZhbHVlIHtcbiAgY29sb3I6ICMzZjUxYjUgIWltcG9ydGFudDtcbn1cbi5PYmplY3RJRCAudmFsdWUge1xuICBjb2xvcjogI2Y3NzU0YyAhaW1wb3J0YW50O1xufVxuLlJlZ0V4cCAudmFsdWUge1xuICBjb2xvcjogIzk5OSAhaW1wb3J0YW50O1xufVxuLlRpbWVzdGFtcCAudmFsdWUge1xuICBjb2xvcjogIzMzMyAhaW1wb3J0YW50O1xufVxuLkNvZGUgLnZhbHVlIHtcbiAgY29sb3I6ICMwMDUzYTYgIWltcG9ydGFudDtcbn1cbi5tZXRhLWRhdGEge1xuICAvKiBmb250LXN0eWxlOiBpdGFsaWM7ICovXG4gIGNvbG9yOiAjOTk5ICFpbXBvcnRhbnQ7XG4gIGZvbnQtc2l6ZTogeC1zbWFsbCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogMTAwO1xufVxuLmtleSB7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIGNvbG9yOiAjNDQ0O1xuICBmb250LXNpemU6IHNtYWxsZXI7XG59XG4udmFsdWUge1xuICBmb250LXdlaWdodDogNjAwO1xuICBmb250LXNpemU6IHNtYWxsZXI7XG4gIGNvbG9yOiAjOTk5O1xuICB3b3JkLWJyZWFrOiBicmVhay1hbGw7XG59XG4uZmllbGRzZXQge1xuICBsaW5lLWhlaWdodDogMThweDtcbiAgd29yZC13cmFwOiBicmVhay13b3JkO1xufVxuLmNvbGxhcHNlZDo6YmVmb3JlIHtcbiAgLyogY29udGVudDogJ1xcMjVCNyc7ICovXG4gIC8qIGNvbnRlbnQ6ICcrJzsgKi9cbiAgY29udGVudDogJ1xcMjc2Ric7XG59XG4uZXhwYW5kZWQ6OmJlZm9yZSB7XG4gIC8qIGNvbnRlbnQ6ICdcXDI1RTInOyAqL1xuICAvKiBjb250ZW50OiAnLSc7ICovXG4gIGNvbnRlbnQ6ICdcXDI3NkYnO1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIC13ZWJraXQtdHJhbnNmb3JtOiByb3RhdGUoNDBkZWcpO1xuICAtbW96LXRyYW5zZm9ybTogcm90YXRlKDQwZGVnKTtcbiAgLW8tdHJhbnNmb3JtOiByb3RhdGUoNDBkZWcpO1xuICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZyk7XG59XG4udG9nZ2xlIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAtMTZweDtcbiAgY3Vyc29yOiBwb2ludGVyO1xuICBjb2xvcjogI2IxYTFhMSAhaW1wb3J0YW50O1xuICB3aWR0aDogMTJweDtcbiAgbGluZS1oZWlnaHQ6IDEycHg7XG4gIHRvcDogNHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGN1cnNvcjogcG9pbnRlcjtcbiAgZm9udC1zaXplOiB4LXNtYWxsO1xufVxuXG4uZmllbGRzZXQge1xuICBkaXNwbGF5OiBpbmxpbmUtZmxleDtcbn1cblxuLmZ1bGwtdGV4dCB7XG4gIGhlaWdodDogYXV0byAhaW1wb3J0YW50O1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/document/document.component.ts":
  /*!************************************************!*\
    !*** ./src/app/document/document.component.ts ***!
    \************************************************/

  /*! exports provided: DocumentComponent */

  /***/
  function srcAppDocumentDocumentComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DocumentComponent", function () {
      return DocumentComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");

    var DocumentComponent = /*#__PURE__*/function () {
      function DocumentComponent() {
        _classCallCheck(this, DocumentComponent);

        this.originalOrder = function (a, b) {
          return 0;
        };
      }

      _createClass(DocumentComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "clicked",
        value: function clicked(e, row) {
          e.stopPropagation();
          var thisClassList = e.target.classList;

          if (thisClassList.contains('expanded')) {
            thisClassList.replace('expanded', 'collapsed');
          } else {
            thisClassList.replace('collapsed', 'expanded');
          }

          var targetEl = e.target.tagName === 'I' ? e.target.parentNode.parentNode : e.target.parentNode;
          var children = targetEl.querySelector('ul') || targetEl.nextSibling && targetEl.nextSibling.querySelector && targetEl.nextSibling.querySelector('ul');

          if (children && children.classList) {
            var classList = children.classList;

            if (classList.contains('open')) {
              classList.remove('open');
            } else {
              classList.add('open');
            }
          }
        }
      }, {
        key: "isEmptyObject",
        value: function isEmptyObject(obj) {
          return obj && Object.keys(obj).length === 0;
        }
      }, {
        key: "showMoreLessText",
        value: function showMoreLessText(e, value) {
          e.preventDefault();
          var thisClassList = e.target.classList;

          if (thisClassList.contains('expanded')) {
            thisClassList.replace('expanded', 'collapsed');
          } else {
            thisClassList.replace('collapsed', 'expanded');
          }

          var flag = e.target.previousElementSibling.classList.toggle('full-text');

          if (flag) {
            e.target.previousElementSibling.innerText = "\"".concat(value, "\"");
          } else {
            e.target.previousElementSibling.innerText = "\"".concat(value.substring(0, 79), "...\"");
          }
        }
      }]);

      return DocumentComponent;
    }();

    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], DocumentComponent.prototype, "data", void 0);
    DocumentComponent = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-document',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./document.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/document/document.component.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./document.component.css */
      "./src/app/document/document.component.css"))["default"]]
    })], DocumentComponent);
    /***/
  },

  /***/
  "./src/environments/environment.ts":
  /*!*****************************************!*\
    !*** ./src/environments/environment.ts ***!
    \*****************************************/

  /*! exports provided: environment */

  /***/
  function srcEnvironmentsEnvironmentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "environment", function () {
      return environment;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js"); // This file can be replaced during build by using the `fileReplacements` array.
    // `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
    // The list of file replacements can be found in `angular.json`.


    var environment = {
      production: false,
      apiRoot: 'http://localhost:4321'
    };
    /*
     * For easier debugging in development mode, you can import the following file
     * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
     *
     * This import should be commented out in production mode because it will have a negative impact
     * on performance if an error is thrown.
     */
    // import 'zone.js/dist/zone-error';  // Included with Angular CLI.

    /***/
  },

  /***/
  "./src/main.ts":
  /*!*********************!*\
    !*** ./src/main.ts ***!
    \*********************/

  /*! no exports provided */

  /***/
  function srcMainTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/platform-browser-dynamic */
    "./node_modules/@angular/platform-browser-dynamic/fesm2015/platform-browser-dynamic.js");
    /* harmony import */


    var _app_app_module__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./app/app.module */
    "./src/app/app.module.ts");
    /* harmony import */


    var _environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./environments/environment */
    "./src/environments/environment.ts");

    if (_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].production) {
      Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["enableProdMode"])();
    }

    Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_2__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_3__["AppModule"])["catch"](function (err) {
      return console.error(err);
    });
    /***/
  },

  /***/
  0:
  /*!***************************!*\
    !*** multi ./src/main.ts ***!
    \***************************/

  /*! no static exports found */

  /***/
  function _(module, exports, __webpack_require__) {
    module.exports = __webpack_require__(
    /*! /Users/unidev/driving-data-warehouse-api/data-admin-client/client/src/main.ts */
    "./src/main.ts");
    /***/
  }
}, [[0, "runtime", "vendor"]]]);
//# sourceMappingURL=main-es5.js.map